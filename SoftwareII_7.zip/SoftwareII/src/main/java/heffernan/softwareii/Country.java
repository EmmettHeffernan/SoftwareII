package heffernan.softwareii;

import java.security.Timestamp;
import java.time.ZonedDateTime;

public class Country {

    private Integer Country_ID;
    private String Country;
    private ZonedDateTime Create_Date;
    private String Created_By;
    private Timestamp Last_Update;
    private String Last_Updated_By;

    public Country(Integer Country_ID, String Country, ZonedDateTime Create_Date, String Created_By, Timestamp Last_Update, String Last_Updated_By)
    {

        this.Country_ID = Country_ID;
        this.Country = Country;
        this.Create_Date = Create_Date;
        this.Created_By = Created_By;
        this.Last_Update = Last_Update;
        this.Last_Updated_By = Last_Updated_By;

    }

}
