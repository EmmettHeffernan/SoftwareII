package heffernan.softwareii.helper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class First_Level_DivisionsQuery {

    public static ResultSet accessDBFLDTable() {
        Connection connection;
        connection = JDBC.connection;
        ResultSet rs = null;

        try{

            String sql = "SELECT first_level_divisions.Division, countries.Country FROM (first_level_division INNER JOIN countries ON first_level_divisions.Country_ID = countries.Country_ID)";
            PreparedStatement ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

}
