package heffernan.softwareii.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * The "AppointmentReportTableRow" class represents a row of data for appointment reports.
 * It's members include appointment type, month, and the total of appointments.
 */
public class AppointmentReportTableRow {
    private final StringProperty appointmentType;
    private final StringProperty month;
    private final IntegerProperty totalAppointments;

    /**
     * Constructs a "AppointmentReportTableRow" object with the following attributes for table view use
     * @param appointmentType
     * @param month
     * @param totalAppointments
     */
    public AppointmentReportTableRow(String appointmentType, String month, Integer totalAppointments) {
        this.appointmentType = new SimpleStringProperty(appointmentType);
        this.month = new SimpleStringProperty(month);
        this.totalAppointments = new SimpleIntegerProperty(totalAppointments);
    }

    /**
     * Gets the property of the appointment type.
     * @return Appointment type property.
     */
    public StringProperty getAppointmentType() {
        return appointmentType;
    }

    /**
     * Gets the property for the month
     * @return Month property
     */
    public StringProperty getMonth() {
        return month;
    }

    /**
     * Gets the property for the total number of appointments.
     * @return The total appointments property.
     */
    public IntegerProperty getTotalAppointments() {
        return totalAppointments;
    }

}
