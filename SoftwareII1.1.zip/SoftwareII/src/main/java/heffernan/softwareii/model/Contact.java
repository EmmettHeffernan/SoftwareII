package heffernan.softwareii.model;

/**
 * The "Contact" class represents a contact entity with attributes such as Contact ID, Contact Name, and Email
 */
public class Contact {

    private Integer Contact_ID;
    private String Contact_Name;
    private String Email;

    /**
     * Constructs a "Contact" objects with the following attributes.
     * @param Contact_ID
     * @param Contact_Name
     * @param Email
     */
    public Contact(Integer Contact_ID, String Contact_Name, String Email)
    {
        this.Contact_ID =  Contact_ID;
        this.Contact_Name = Contact_Name;
        this.Email = Email;
    }
}
