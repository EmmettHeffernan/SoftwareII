package heffernan.softwareii.controller;

import heffernan.softwareii.Main;
import heffernan.softwareii.helper.AppointmentsQuery;
import heffernan.softwareii.helper.ContactsQuery;
import heffernan.softwareii.helper.CountriesQuery;
import heffernan.softwareii.helper.UsersQuery;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Array;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

public class AddAppointmentController {

    @FXML
    private DatePicker addAppointmentEndDate;

    @FXML
    private DatePicker addAppointmentStartDate;

    @FXML
    private ComboBox addAppointmentStartTime;

    @FXML
    private ComboBox addAppointmentEndTime;

    @FXML
    private TextField addAppointmentIDTxt;

    @FXML
    private TextField addAppointmentTitleTxt;

    @FXML
    private TextField addAppointmentDescriptionTxt;

    @FXML
    private TextField addAppointmentLocationTxt;

    @FXML
    private ComboBox<String> addAppointmentContactCombo;

    @FXML
    private TextField addAppointmentTypeTxt;

    @FXML
    private TextField addAppointmentCustomerIDTxt;

    @FXML
    private TextField addAppointmentUserIDTxt;

    @FXML
    private Button addAppointmentSaveBtn;

    @FXML
    private Button addAppointmentCancelBtn;

    private ResourceBundle bundle;

    @FXML
    void initialize() throws SQLException {
        Locale locale = Locale.getDefault();
        bundle = ResourceBundle.getBundle("lang", locale);
        setAddAppointmentContactCombo();
        setAddAppointmentTimes();
        addAppointmentIDTxt.setText(String.valueOf(AppointmentsQuery.getNextAppointmentID()));
    }

    private String convertToUTCDateTime(String localDate, String localTime) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime localDateTime = LocalDateTime.parse(localDate + " " + localTime, dateTimeFormatter);
        ZoneId zoneId = ZoneId.of("UTC");
        ZonedDateTime localZonedDateTime = localDateTime.atZone(ZoneId.systemDefault());
        ZonedDateTime utcDateTime = localZonedDateTime.withZoneSameInstant(zoneId);
        return utcDateTime.format(dateTimeFormatter);
    }

    private boolean isDuringBusinessOperation(String startDate, String startTime, String endDate, String endTime){
        ZoneId etZone = ZoneId.of("America/New_York");
        LocalDateTime startDateTime = LocalDateTime.parse(startDate+"T"+startTime);
        LocalDateTime endDateTime = LocalDateTime.parse(endDate+"T"+endTime);
        ZonedDateTime startET = startDateTime.atZone(ZoneId.systemDefault()).withZoneSameInstant(etZone);
        ZonedDateTime endET = endDateTime.atZone(ZoneId.systemDefault()).withZoneSameInstant(etZone);
        LocalTime businessOpen = LocalTime.of(8, 0);
        LocalTime businessClose = LocalTime.of(22, 0);
        return !startET.toLocalTime().isBefore(businessOpen) && !endET.toLocalTime().isAfter(businessClose) &&
                (startET.getDayOfWeek() != DayOfWeek.SATURDAY && startET.getDayOfWeek() != DayOfWeek.SUNDAY) &&
                (endET.getDayOfWeek() != DayOfWeek.SATURDAY && endET.getDayOfWeek() != DayOfWeek.SUNDAY);
    }

    private void setAddAppointmentContactCombo() {
        ResultSet contacts = ContactsQuery.selectContacts();
        try {
            while (contacts.next()){
                String contactName = contacts.getString(1);
                addAppointmentContactCombo.getItems().add(contactName);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    private void setAddAppointmentTimes(){
        List<String> hours = Arrays.asList("00:00:00", "01:00:00", "02:00:00", "03:00:00", "04:00:00", "05:00:00", "06:00:00", "07:00:00", "08:00:00", "09:00:00", "10:00:00", "11:00:00",
                "12:00:00", "13:00:00", "14:00:00", "15:00:00", "16:00:00", "17:00:00", "18:00:00", "19:00:00","20:00:00", "21:00:00", "22:00:00", "23:00:00");
        addAppointmentStartTime.getItems().addAll(hours);
        addAppointmentEndTime.getItems().addAll(hours);
    }

    @FXML
    void onActionSave(ActionEvent actionEvent) throws IOException, SQLException {

        String title = addAppointmentTitleTxt.getText();
        String description = addAppointmentDescriptionTxt.getText();
        String location = addAppointmentLocationTxt.getText();
        String contact = addAppointmentContactCombo.getValue();
        String type = addAppointmentTypeTxt.getText();
        LocalDate startDate = addAppointmentStartDate.getValue();
        Object startTime = addAppointmentStartTime.getValue();
        LocalDate endDate = addAppointmentEndDate.getValue();
        Object endTime = addAppointmentEndTime.getValue();
        String customerID = addAppointmentCustomerIDTxt.getText();
        String userID = addAppointmentUserIDTxt.getText();

        if(title.isEmpty() || title.length() > 50 || description.isEmpty() || description.length() > 50 || location.isEmpty() || location.length() > 50 ||
                (contact == null) || type.isEmpty() || type.length() > 50 || startDate == null || startTime == null || endDate == null || endTime == null || customerID.isEmpty() || userID.isEmpty()){
            showError("addAppointment.SaveErrorTitle", "addAppointment.SaveErrorMessage");
            return;
        }
        else if(!isDuringBusinessOperation(startDate.toString(), startTime.toString(), endDate.toString(), endTime.toString())){
            showError("addAppointment.OutsideBusinessHoursTitle", "addAppointment.OutsideBusinessHoursMessage");
            return;
        }
        else if(hasOverlap(Integer.parseInt(customerID), startDate.toString(), startTime.toString(), endDate.toString(), endTime.toString())){
            showError("addAppointment.scheduleConflictTitle", "addAppointment.scheduleConflictMessage");
            return;
        }
        AppointmentsQuery.addAppointment(title, description, location, contact, type,
                convertToUTCDateTime(startDate.toString(), startTime.toString()),
                convertToUTCDateTime(endDate.toString(), endTime.toString()), Integer.parseInt(customerID), Integer.parseInt(userID));

        FXMLLoader loader = new FXMLLoader(Main.class.getResource("mainMenu-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) addAppointmentSaveBtn.getScene().getWindow();
        currentStage.close();
    }

    @FXML
    void onActionCancel(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("mainMenu-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) addAppointmentCancelBtn.getScene().getWindow();
        currentStage.close();
    }

    private boolean hasOverlap(int customerID, String startDate, String startTime, String endDate, String endTime) throws SQLException {
        ResultSet rs = AppointmentsQuery.getCustomerScheduledAppointments(customerID);
        while(rs.next()){
            String scheduledStart = rs.getString(1);
            String scheduledEnd = rs.getString(2);
            LocalDateTime scheduledStartTime = LocalDateTime.parse(scheduledStart, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            LocalDateTime scheduledEndTime = LocalDateTime.parse(scheduledEnd, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            LocalDateTime newStartTime = LocalDateTime.parse(convertToUTCDateTime(startDate, startTime), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            LocalDateTime newEndTime = LocalDateTime.parse(convertToUTCDateTime(endDate, endTime), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

            if ((newStartTime.isBefore(scheduledEndTime)) && newEndTime.isAfter(scheduledStartTime)) {
                return true;
            }
        }
        return false;
    }

    private void showError(String title, String message){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(bundle.getString(title));
        alert.setContentText(bundle.getString(message));
        alert.showAndWait();
    }

}
