package heffernan.softwareii.helper;

import java.sql.*;

/**
 * The "ContactsQuery" class provides methods related to retrieving contact info
 */
public abstract class ContactsQuery {

    /**
     * Gets the name of every contact
     * @return ResultSet
     */
    public static ResultSet selectContacts() {
        Connection connection;
        connection = JDBC.connection;
        ResultSet rs = null;
        try{

            String sql = "SELECT Contact_Name FROM contacts";
            PreparedStatement ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

    /**
     * Gets a contact's ID by their name.
     * @param Contact_Name
     * @return ResultSet
     */
    public static ResultSet selectContact_ID(String Contact_Name) {
        Connection connection;
        connection = JDBC.connection;
        ResultSet rs = null;
        try{
            String sql = "SELECT Contact_ID FROM contacts WHERE contacts.Contact_Name = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, Contact_Name);
            rs = ps.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

}
