package heffernan.softwareii.logger;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LoginActivityLogger {
    private static final String LOG_FILE = "login_activity.txt";

    public static void logLoginAttempt(String username, boolean valid) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(LOG_FILE, true))) {
            String now = getCurrentstamp();
            String outcome = valid ? "Success" : "Fail";
            String logEntry = String.format("[%s] User: %s, Login Outcome: %s%n", now, username, outcome);
            writer.write(logEntry);
        }
    }

    private static String getCurrentstamp() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return dateFormat.format(new Date());
    }
}
