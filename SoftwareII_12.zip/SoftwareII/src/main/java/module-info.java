module heffernan.softwareii {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens heffernan.softwareii to javafx.fxml;
    exports heffernan.softwareii;
    exports heffernan.softwareii.controller;
    opens heffernan.softwareii.controller to javafx.fxml;
    exports heffernan.softwareii.model;
    opens heffernan.softwareii.model to javafx.fxml;
}