package heffernan.softwareii;
import heffernan.softwareii.helper.CustomersQuery;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.util.Locale;
import java.util.ResourceBundle;

public class mainMenuController implements Initializable {

    @FXML
    private TableColumn customersTableIDCol;

    @FXML
    private TableColumn customersTableNameCol;

    @FXML
    private TableColumn customersTableAddressCol;

    @FXML
    private TableColumn customersTablePostalCodeCol;

    @FXML
    private TableColumn customersTablePhoneCol;

    @FXML
    private TableColumn customersTableDivisionIDCol;

    @FXML
    private TableColumn customersTableStateCol;

    @FXML
    private TableColumn customersTableCountryCol;

    @FXML
    private TableView mainMenuCustomersTableView;

    @FXML
    private TableView mainMenuAppointmentsTableView;

    @FXML
    private Button mainMenuAddCustomerBtn;

    @FXML
    private Button mainMenuUpdateCustomerBtn;

    @FXML
    private Button mainMenuCustomerDelete;

    @FXML
    private Button mainMenuAppointmentAddBtn;

    @FXML
    private Button mainMenuUpdateAppointmentBtn;

    @FXML
    private Button mainMenuDeleteAppointmentBtn;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ResultSet rs = CustomersQuery.accessDBCustomersTable();

    }

    public void onActionAddCustomer(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("addCustomer-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) mainMenuAddCustomerBtn.getScene().getWindow();
        currentStage.close();
    }

    public void onActionUpdateCustomer(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("updateCustomer-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) mainMenuAddCustomerBtn.getScene().getWindow();
        currentStage.close();
    }

    public void onActionDeleteCustomer(ActionEvent actionEvent) {
    }

    public void onActionAddAppointment(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("addAppointment-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) mainMenuAddCustomerBtn.getScene().getWindow();
        currentStage.close();
    }

    public void onActionUpdateAppointment(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("updateAppointment-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) mainMenuAddCustomerBtn.getScene().getWindow();
        currentStage.close();
    }

    public void onActionDeleteAppointment(ActionEvent actionEvent) {
    }
}
