package heffernan.softwareii.controller;

import heffernan.softwareii.Main;
import heffernan.softwareii.helper.AppointmentsQuery;
import heffernan.softwareii.helper.CountriesQuery;
import heffernan.softwareii.model.AppointmentReportTableRow;
import heffernan.softwareii.model.ContactsScheduleTableRow;
import heffernan.softwareii.model.CustomersReportTableRow;
import javafx.beans.binding.Bindings;
import javafx.beans.property.IntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * The "reportController" class controls the report page and handles it's data retrieval.
 */
public class reportController {

    @FXML
    private Button reportExitBtn;

    @FXML
    private TableView<AppointmentReportTableRow> reportAppointmentsTableview;

    @FXML
    private TableColumn<AppointmentReportTableRow, String> appointmentsTypeCol;

    @FXML
    private TableColumn<AppointmentReportTableRow, String> appointmentsMonthCol;

    @FXML
    private TableColumn<AppointmentReportTableRow, Integer> appointmentsTotalAppoinmentsCol;

    @FXML
    private TableView<ContactsScheduleTableRow> anikaCostaScheduleTableView;

    @FXML
    private TableColumn<ContactsScheduleTableRow, Integer> anikaCostaAppointmentIDCol;

    @FXML
    private TableColumn<ContactsScheduleTableRow, String> anikaCostaTitleCol;

    @FXML
    private TableColumn<ContactsScheduleTableRow, String> anikaCostaTypeCol;

    @FXML
    private TableColumn<ContactsScheduleTableRow, String> anikaCostaDescriptionCol;

    @FXML
    private TableColumn<ContactsScheduleTableRow, String> anikaCostaStartCol;

    @FXML
    private TableColumn<ContactsScheduleTableRow, String> anikaCostaEndCol;

    @FXML
    private TableColumn<ContactsScheduleTableRow, Integer> anikaCostaCustomerIDCol;

    @FXML
    private TableView<ContactsScheduleTableRow> danielGarciaScheduleTableView;

    @FXML
    private TableColumn<ContactsScheduleTableRow, Integer> danielGarciaAppointmentIDCol;

    @FXML
    private TableColumn<ContactsScheduleTableRow, String> danielGarciaTitleCol;

    @FXML
    private TableColumn<ContactsScheduleTableRow, String> danielGarciaTypeCol;

    @FXML
    private TableColumn<ContactsScheduleTableRow, String> danielGarciaDescriptionCol;

    @FXML
    private TableColumn<ContactsScheduleTableRow, String> danielGarciaStartCol;

    @FXML
    private TableColumn<ContactsScheduleTableRow, String> danielGarciaEndCol;

    @FXML
    private TableColumn<ContactsScheduleTableRow, Integer> danielGarciaCustomerIDCol;

    @FXML
    private TableView<ContactsScheduleTableRow> liLeeScheduleTableView;

    @FXML
    private TableColumn<ContactsScheduleTableRow, Integer> liLeeAppointmentIDCol;

    @FXML
    private TableColumn<ContactsScheduleTableRow, String> liLeeTitleCol;

    @FXML
    private TableColumn<ContactsScheduleTableRow, String> liLeeTypeCol;

    @FXML
    private TableColumn<ContactsScheduleTableRow, String> liLeeDescriptionCol;

    @FXML
    private TableColumn<ContactsScheduleTableRow, String> liLeeStartCol;

    @FXML
    private TableColumn<ContactsScheduleTableRow, String> liLeeEndCol;

    @FXML
    private TableColumn<ContactsScheduleTableRow, Integer> liLeeCustomerIDCol;

    @FXML
    private TableView<CustomersReportTableRow> reportCustomersTableView;

    @FXML
    private TableColumn<CustomersReportTableRow, String> customersCountryCol;

    @FXML
    private TableColumn<CustomersReportTableRow, Integer> customersTotalCustomersCol;

    /**
     * Initializes the report dashboard and sets up the tables for data binding.
     */
    @FXML
    private void initialize() {

        /**
         * Lambda Expression 1: Bind the cell value to the type property, using lambda here simplifies the code by efficiently setting the table cell up to display String type data correctly
         */
        appointmentsTypeCol.setCellValueFactory(cellData -> cellData.getValue().getAppointmentType());
        appointmentsMonthCol.setCellValueFactory(cellData -> cellData.getValue().getMonth());
        /**
         * Lambda Expression 2: Bind the cell value to the totalAppointments property, using lambda here simplifies the code by efficiently setting the table cell up to display Integer type data correctly using the "Bindings" class.
         */
        appointmentsTotalAppoinmentsCol.setCellValueFactory(cellData -> {
            IntegerProperty intValue = cellData.getValue().getTotalAppointments();
            return Bindings.createObjectBinding(() -> intValue.get());
        });

        anikaCostaAppointmentIDCol.setCellValueFactory(cellData -> {
            IntegerProperty intValue = cellData.getValue().getAppointmentID();
            return Bindings.createObjectBinding(() -> intValue.get());
        });
        anikaCostaTitleCol.setCellValueFactory(cellData -> cellData.getValue().getTitle());
        anikaCostaTypeCol.setCellValueFactory(cellData -> cellData.getValue().getType());
        anikaCostaDescriptionCol.setCellValueFactory(cellData -> cellData.getValue().getDescription());
        anikaCostaStartCol.setCellValueFactory(cellData -> cellData.getValue().getStart());
        anikaCostaEndCol.setCellValueFactory(cellData -> cellData.getValue().getEnd());
        anikaCostaCustomerIDCol.setCellValueFactory(cellData -> {
            IntegerProperty intValue = cellData.getValue().getCustomerID();
            return Bindings.createObjectBinding(() -> intValue.get());
        });

        danielGarciaAppointmentIDCol.setCellValueFactory(cellData -> {
            IntegerProperty intValue = cellData.getValue().getAppointmentID();
            return Bindings.createObjectBinding(() -> intValue.get());
        });
        danielGarciaTitleCol.setCellValueFactory(cellData -> cellData.getValue().getTitle());
        danielGarciaTypeCol.setCellValueFactory(cellData -> cellData.getValue().getType());
        danielGarciaDescriptionCol.setCellValueFactory(cellData -> cellData.getValue().getDescription());
        danielGarciaStartCol.setCellValueFactory(cellData -> cellData.getValue().getStart());
        danielGarciaEndCol.setCellValueFactory(cellData -> cellData.getValue().getEnd());
        danielGarciaCustomerIDCol.setCellValueFactory(cellData -> {
            IntegerProperty intValue = cellData.getValue().getCustomerID();
            return Bindings.createObjectBinding(() -> intValue.get());
        });

        liLeeAppointmentIDCol.setCellValueFactory(cellData -> {
            IntegerProperty intValue = cellData.getValue().getAppointmentID();
            return Bindings.createObjectBinding(() -> intValue.get());
        });
        liLeeTitleCol.setCellValueFactory(cellData -> cellData.getValue().getTitle());
        liLeeTypeCol.setCellValueFactory(cellData -> cellData.getValue().getType());
        liLeeDescriptionCol.setCellValueFactory(cellData -> cellData.getValue().getDescription());
        liLeeStartCol.setCellValueFactory(cellData -> cellData.getValue().getStart());
        liLeeEndCol.setCellValueFactory(cellData -> cellData.getValue().getEnd());
        liLeeCustomerIDCol.setCellValueFactory(cellData -> {
            IntegerProperty intValue = cellData.getValue().getCustomerID();
            return Bindings.createObjectBinding(() -> intValue.get());
        });

        customersCountryCol.setCellValueFactory(cellData -> cellData.getValue().getCountry());
        customersTotalCustomersCol.setCellValueFactory(cellData -> {
            IntegerProperty intValue = cellData.getValue().getCustomerCount();
            return Bindings.createObjectBinding(() -> intValue.get());
        });

        setReportAppointmentsTableview();
        setContactScheduleTableView();
        setReportCustomersTableView();
    }

    /**
     * Both retrieves and populates the reportAppointmentsTable with data.
     */
    private void setReportAppointmentsTableview() {
        try{
            ResultSet rs = AppointmentsQuery.getAppointmentsByTypeAndMonth();
            ObservableList<AppointmentReportTableRow> rows = FXCollections.observableArrayList();
            while(rs.next()){
                String type = rs.getString(1);
                String start = rs.getString(2);
                Integer totalAppointments = rs.getInt(3);

                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                LocalDateTime dateTime = LocalDateTime.parse(start, formatter);

                String month = dateTime.getMonth().toString();

                rows.add(new AppointmentReportTableRow(type, month, totalAppointments));
            }
            reportAppointmentsTableview.setItems(rows);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    /**
     * Both retrieves and populates the contact schedule tables with data.
     */
    private void setContactScheduleTableView() {
        try{
            ResultSet rsAnika = AppointmentsQuery.getContactAppointmentSchedule("Anika Costa");
            ObservableList<ContactsScheduleTableRow> anikaCostaRows = FXCollections.observableArrayList();
            while(rsAnika.next()){
                Integer appointmentID = rsAnika.getInt(1);
                String title = rsAnika.getString(2);
                String type = rsAnika.getString(3);
                String description = rsAnika.getString(4);
                String start = rsAnika.getString(5);
                String end = rsAnika.getString(6);
                Integer customerID = rsAnika.getInt(7);

                anikaCostaRows.add(new ContactsScheduleTableRow(appointmentID, title, type,description, start, end, customerID));
            }
            anikaCostaScheduleTableView.setItems(anikaCostaRows);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        try{
            ResultSet rsDaniel = AppointmentsQuery.getContactAppointmentSchedule("Daniel Garcia");
            ObservableList<ContactsScheduleTableRow> danielGarciaRows = FXCollections.observableArrayList();
            while(rsDaniel.next()){
                Integer appointmentID = rsDaniel.getInt(1);
                String title = rsDaniel.getString(2);
                String type = rsDaniel.getString(3);
                String description = rsDaniel.getString(4);
                String start = rsDaniel.getString(5);
                String end = rsDaniel.getString(6);
                Integer customerID = rsDaniel.getInt(7);

                danielGarciaRows.add(new ContactsScheduleTableRow(appointmentID, title, type,description, start, end, customerID));
            }
            danielGarciaScheduleTableView.setItems(danielGarciaRows);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        try{
            ResultSet rsLi = AppointmentsQuery.getContactAppointmentSchedule("Li Lee");
            ObservableList<ContactsScheduleTableRow> liLeeRows = FXCollections.observableArrayList();
            while(rsLi.next()){

                Integer appointmentID = rsLi.getInt(1);
                String title = rsLi.getString(2);
                String type = rsLi.getString(3);
                String description = rsLi.getString(4);
                String start = rsLi.getString(5);
                String end = rsLi.getString(6);
                Integer customerID = rsLi.getInt(7);

                liLeeRows.add(new ContactsScheduleTableRow(appointmentID, title, type,description, start, end, customerID));
            }
            liLeeScheduleTableView.setItems(liLeeRows);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    /**
     * Both retrieves and populates the customers by country TableView with data.
     */
    private void setReportCustomersTableView(){
        try{
            ResultSet rs = CountriesQuery.getCustomerCountByCountry();
            ObservableList<CustomersReportTableRow> countryCustomerCountRows = FXCollections.observableArrayList();
            while(rs.next()){
                String country = rs.getString(1);
                Integer customerCount = rs.getInt(2);
                countryCustomerCountRows.add(new CustomersReportTableRow(country, customerCount));
            }
            reportCustomersTableView.setItems(countryCustomerCountRows);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    /**
     * Exits the page by loading back to the main menu.
     * @param actionEvent
     * @throws IOException
     */
    public void onActionExit(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("mainMenu-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
        Stage currentStage = (Stage) reportExitBtn.getScene().getWindow();
        currentStage.close();
    }
}


