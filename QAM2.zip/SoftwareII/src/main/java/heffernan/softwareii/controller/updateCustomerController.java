package heffernan.softwareii.controller;

import heffernan.softwareii.Main;
import heffernan.softwareii.helper.CountriesQuery;
import heffernan.softwareii.helper.CustomersQuery;
import heffernan.softwareii.helper.First_Level_DivisionsQuery;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Locale;
import java.util.ResourceBundle;

public class updateCustomerController {

    @FXML
    private TextField updateCustomerIDTxt;

    @FXML
    private TextField updateCustomerNameTxt;

    @FXML
    private TextField updateCustomerAddressTxt;

    @FXML
    private TextField updateCustomerPostalCodeTxt;

    @FXML
    private ComboBox<String> updateCustomerCountryCombo;

    @FXML
    private ComboBox<String> updateCustomerFLDCombo;

    @FXML
    private TextField updateCustomerPhoneTxt;

    @FXML
    private Button updateCustomerSaveBtn;

    @FXML
    private Button updateCustomerCancelBtn;

    private ResourceBundle bundle;

    @FXML
    void initialize(){
        Locale locale = Locale.getDefault();
        bundle = ResourceBundle.getBundle("lang", locale);
        setUpdateCustomerCountryCombo();
    }

    private void setUpdateCustomerCountryCombo() {
        ResultSet countries = CountriesQuery.accessDBCountriesTable();
        try {
            while (countries.next()){
                String countryName = countries.getString(2);
                updateCustomerCountryCombo.getItems().add(countryName);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void onActionSelect(ActionEvent actionEvent) {
        String selectedCountry = updateCustomerCountryCombo.getSelectionModel().getSelectedItem();
        updateCustomerFLDCombo.getItems().clear();
        setUpdateCustomerFLDCombo(selectedCountry);
    }

    private void setUpdateCustomerFLDCombo(String country) {
        ResultSet divisions = First_Level_DivisionsQuery.accessDBFLDTable(country);
        try {
            while (divisions.next()) {
                String divisionCountry = divisions.getString(2);

                if (divisionCountry.equals(country)) {
                    String division = divisions.getString(1);
                    updateCustomerFLDCombo.getItems().add(division);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void onActionSave(ActionEvent actionEvent) throws IOException, SQLException {

        String customerName = updateCustomerNameTxt.getText();
        String customerAddress = updateCustomerAddressTxt.getText();
        String customerPostal = updateCustomerPostalCodeTxt.getText();
        String customerPhone = updateCustomerPhoneTxt.getText();
        String customerCountry = updateCustomerCountryCombo.getValue();
        String customerFLD = updateCustomerFLDCombo.getValue();

        if (customerName.isEmpty() || customerAddress.isEmpty() || customerPostal.isEmpty() || customerPhone.isEmpty() || customerCountry.isEmpty() || customerFLD.isEmpty()
                || customerName.length() > 50 || customerAddress.length() > 100 || customerPostal.length() > 50 || customerPhone.length() > 50){
            showError("addCustomer.SaveErrorTitle","addCustomer.SaveErrorMessage");
            return;
        }

        CustomersQuery.updateCustomer(Integer.parseInt(updateCustomerIDTxt.getText()), updateCustomerNameTxt.getText(), updateCustomerAddressTxt.getText(), updateCustomerPostalCodeTxt.getText(), updateCustomerPhoneTxt.getText(), updateCustomerFLDCombo.getValue().toString());

        FXMLLoader loader = new FXMLLoader(Main.class.getResource("mainMenu-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) updateCustomerSaveBtn.getScene().getWindow();
        currentStage.close();
    }

    @FXML
    void onActionCancel(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("mainMenu-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) updateCustomerCancelBtn.getScene().getWindow();
        currentStage.close();
    }

    public void setCustomerData(Integer customerID, String name, String address, String postalCode, String phone, String state, String country) {
        updateCustomerIDTxt.setText(customerID.toString());
        updateCustomerNameTxt.setText(name);
        updateCustomerAddressTxt.setText(address);
        updateCustomerPostalCodeTxt.setText(postalCode);
        updateCustomerPhoneTxt.setText(phone);
        updateCustomerCountryCombo.setValue(country);
        updateCustomerFLDCombo.setValue(state);
        setUpdateCustomerFLDCombo(updateCustomerCountryCombo.getValue());
    }

    private void showError(String title, String message){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(bundle.getString(title));
        alert.setContentText(bundle.getString(message));
        alert.showAndWait();
    }

}
