package heffernan.softwareii.controller;
import heffernan.softwareii.model.Appointment;
import heffernan.softwareii.model.Country;
import heffernan.softwareii.model.Customer;
import heffernan.softwareii.Main;
import heffernan.softwareii.helper.AppointmentsQuery;
import heffernan.softwareii.helper.CustomersQuery;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.ResourceBundle;

public class mainMenuController implements Initializable {

    @FXML
    private Button mainMenuReportBtn;

    @FXML
    private TabPane mainMenuAppointmentTabPane;

    @FXML
    private Tab mainMenuAppointmentsWeekTab;

    @FXML
    private Tab mainMenuAppointmentWeekTab;

    @FXML
    private TableView<Appointment> mainMenuAppointmentsWeekTableView;

    @FXML
    private TableColumn<Appointment, Integer> appointmentsWeekTableIDCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsWeekTableTitleCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsWeekTableDescriptionCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsWeekTableLocationCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsWeekTableContactCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsWeekTableTypeCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsWeekTableStartCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsWeekTableEndCol;

    @FXML
    private TableColumn<Appointment, Integer> appointmentsWeekTableCusIDCol;

    @FXML
    private TableColumn<Appointment, Integer> appoinmentsWeekTableUserIDCol;

    @FXML
    private Tab mainMenuAppointmentsMonthTab;

    @FXML
    private TableView<Appointment> mainMenuAppointmentsMonthTableView;

    @FXML
    private TableColumn<Appointment, Integer> appointmentsMonthTableIDCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsMonthTableTitleCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsMonthTableDescriptionCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsMonthTableLocationCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsMonthTableContactCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsMonthTableTypeCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsMonthTableStartCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsMonthTableEndCol;

    @FXML
    private TableColumn<Appointment, Integer> appointmentsMonthTableCusIDCol;

    @FXML
    private TableColumn<Appointment, Integer> appoinmentsMonthTableUserIDCol;

    @FXML
    private  DatePicker mainMenuScheduleDatePicker;

    @FXML
    private TableColumn<Customer, Integer> customersTableIDCol;

    @FXML
    private TableColumn<Customer, String> customersTableNameCol;

    @FXML
    private TableColumn<Customer, String> customersTableAddressCol;

    @FXML
    private TableColumn<Customer, String> customersTablePostalCodeCol;

    @FXML
    private TableColumn<Customer, String> customersTablePhoneCol;

    @FXML
    private TableColumn<Customer, String> customersTableStateCol;

    @FXML
    private TableColumn<Country, String> customersTableCountryCol;

    @FXML
    private TableView<Customer> mainMenuCustomersTableView;

    @FXML
    private TableView<Appointment> mainMenuAppointmentsTableView;

    @FXML
    private TableColumn<Appointment, Integer> appointmentsTableIDCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsTableTitleCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsTableDescriptionCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsTableLocationCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsTableContactCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsTableTypeCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsTableStartCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsTableEndCol;

    @FXML
    private TableColumn<Appointment, Integer> appointmentsTableCusIDCol;

    @FXML
    private TableColumn<Appointment, Integer> appoinmentsTableUserIDCol;

    @FXML
    private Button mainMenuAddCustomerBtn;

    @FXML
    private Button mainMenuUpdateCustomerBtn;

    @FXML
    private Button mainMenuCustomerDelete;

    @FXML
    private Button mainMenuAppointmentAddBtn;

    @FXML
    private Button mainMenuUpdateAppointmentBtn;

    @FXML
    private Button mainMenuDeleteAppointmentBtn;

    private ResourceBundle bundle;

    private ZoneId userZoneID;

    public void setUserZoneID(ZoneId userZoneID){
        this.userZoneID = userZoneID;
    }

    private String convertToUserTime(String utcTime) {
        utcTime = utcTime.replace(" ", "T") + ".000Z";
        Instant instant = Instant.parse(utcTime);
        ZonedDateTime utcDateTime = instant.atZone(ZoneId.of("UTC"));
        ZonedDateTime userLocalDateTime = utcDateTime.withZoneSameInstant(userZoneID);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String userDateTimeString = userLocalDateTime.format(formatter);
        return userDateTimeString;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setUserZoneID(ZoneId.systemDefault());
        Locale locale = Locale.getDefault();
        bundle = ResourceBundle.getBundle("lang", locale);
        ObservableList<Customer> customers = FXCollections.observableArrayList();
        ResultSet rsCustomers = CustomersQuery.accessDBCustomersTable();

        customersTableIDCol.setCellValueFactory(new PropertyValueFactory<>("Customer_ID"));
        customersTableNameCol.setCellValueFactory(new PropertyValueFactory<>("Customer_Name"));
        customersTableAddressCol.setCellValueFactory(new PropertyValueFactory<>("Address"));
        customersTablePostalCodeCol.setCellValueFactory(new PropertyValueFactory<>("Postal_Code"));
        customersTablePhoneCol.setCellValueFactory(new PropertyValueFactory<>("Phone"));
        customersTableStateCol.setCellValueFactory(new PropertyValueFactory<>("Division"));
        customersTableCountryCol.setCellValueFactory(new PropertyValueFactory<>("Country"));

        appointmentsMonthTableIDCol.setCellValueFactory(new PropertyValueFactory<>("Appointment_ID"));
        appointmentsMonthTableTitleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
        appointmentsMonthTableDescriptionCol.setCellValueFactory(new PropertyValueFactory<>("Description"));
        appointmentsMonthTableLocationCol.setCellValueFactory(new PropertyValueFactory<>("Location"));
        appointmentsMonthTableContactCol.setCellValueFactory(new PropertyValueFactory<>("Contact"));
        appointmentsMonthTableTypeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
        appointmentsMonthTableStartCol.setCellValueFactory(new PropertyValueFactory<>("Start"));
        appointmentsMonthTableEndCol.setCellValueFactory(new PropertyValueFactory<>("End"));
        appointmentsMonthTableCusIDCol.setCellValueFactory(new PropertyValueFactory<>("Customer_ID"));
        appoinmentsMonthTableUserIDCol.setCellValueFactory(new PropertyValueFactory<>("User_ID"));

        appointmentsWeekTableIDCol.setCellValueFactory(new PropertyValueFactory<>("Appointment_ID"));
        appointmentsWeekTableTitleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
        appointmentsWeekTableDescriptionCol.setCellValueFactory(new PropertyValueFactory<>("Description"));
        appointmentsWeekTableLocationCol.setCellValueFactory(new PropertyValueFactory<>("Location"));
        appointmentsWeekTableContactCol.setCellValueFactory(new PropertyValueFactory<>("Contact"));
        appointmentsWeekTableTypeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
        appointmentsWeekTableStartCol.setCellValueFactory(new PropertyValueFactory<>("Start"));
        appointmentsWeekTableEndCol.setCellValueFactory(new PropertyValueFactory<>("End"));
        appointmentsWeekTableCusIDCol.setCellValueFactory(new PropertyValueFactory<>("Customer_ID"));
        appoinmentsWeekTableUserIDCol.setCellValueFactory(new PropertyValueFactory<>("User_ID"));

        mainMenuScheduleDatePicker.setValue(LocalDate.now());
        onActionSelectDate(new ActionEvent());


        try{
            while (rsCustomers.next()) {

                Integer customerID = rsCustomers.getInt(1);
                String customerName = rsCustomers.getString(2);
                String customerAddress = rsCustomers.getString(3);
                String customerPostal = rsCustomers.getString(4);
                String customerPhone = rsCustomers.getString(5);
                String customerState = rsCustomers.getString(6);
                String customerCountry = rsCustomers.getString(7);
                Customer customer = new Customer(customerID, customerName, customerAddress, customerPostal, customerPhone, customerState, customerCountry);
                customers.add(customer);

            }

            mainMenuCustomersTableView.setItems(customers);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void onActionAddCustomer(ActionEvent actionEvent) throws IOException {

        FXMLLoader loader = new FXMLLoader(Main.class.getResource("addCustomer-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) mainMenuAddCustomerBtn.getScene().getWindow();
        currentStage.close();

    }

    public void onActionUpdateCustomer(ActionEvent actionEvent) throws IOException {

        Customer selectedRow = mainMenuCustomersTableView.getSelectionModel().getSelectedItem();

        FXMLLoader loader = new FXMLLoader(Main.class.getResource("updateCustomer-view.fxml"));
        Parent root = loader.load();
        updateCustomerController updateCustomerController = loader.getController();

        if (selectedRow != null){updateCustomerController.setCustomerData(selectedRow.getCustomer_ID(), selectedRow.getCustomer_Name(), selectedRow.getAddress(), selectedRow.getPostal_Code(), selectedRow.getPhone(), selectedRow.getDivision(), selectedRow.getCountry());
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) mainMenuAddCustomerBtn.getScene().getWindow();
            currentStage.close();}
        else{
            showError("mainMenu.noCustomerSelectedTitle", "mainMenu.noCustomerSelectedMessage");
        }

    }

    public void onActionDeleteCustomer(ActionEvent actionEvent) throws SQLException {
        Customer selectedRow = mainMenuCustomersTableView.getSelectionModel().getSelectedItem();
        if(selectedRow != null){

            Integer Appointment_ID = AppointmentsQuery.getCustomerAppointmentBooked(selectedRow.getCustomer_ID());
            if (Appointment_ID<0) {
                CustomersQuery.deleteCustomer(selectedRow.getCustomer_ID());
                ObservableList<Customer> customers = FXCollections.observableArrayList();
                ResultSet rsCustomers = CustomersQuery.accessDBCustomersTable();

                try {
                    while (rsCustomers.next()) {

                        Integer customerID = rsCustomers.getInt(1);
                        String customerName = rsCustomers.getString(2);
                        String customerAddress = rsCustomers.getString(3);
                        String customerPostal = rsCustomers.getString(4);
                        String customerPhone = rsCustomers.getString(5);
                        String customerState = rsCustomers.getString(6);
                        String customerCountry = rsCustomers.getString(7);
                        Customer customer = new Customer(customerID, customerName, customerAddress, customerPostal, customerPhone, customerState, customerCountry);
                        customers.add(customer);

                    }

                    mainMenuCustomersTableView.setItems(customers);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            else{
                showError("mainMenu.scheduleConflictTitle", "mainMenu.scheduleConflictMessage");
            }
        }
        else {
            showError("mainMenu.noCustomerSelectedTitle", "mainMenu.noCustomerSelectedMessage");
        }
    }

    public void onActionAddAppointment(ActionEvent actionEvent) throws IOException {

        FXMLLoader loader = new FXMLLoader(Main.class.getResource("addAppointment-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) mainMenuAddCustomerBtn.getScene().getWindow();
        currentStage.close();

    }

    public void onActionUpdateAppointment(ActionEvent actionEvent) throws IOException {

        Appointment selectedRowWeek = mainMenuAppointmentsWeekTableView.getSelectionModel().getSelectedItem();
        Appointment selectedRowMonth = mainMenuAppointmentsMonthTableView.getSelectionModel().getSelectedItem();

        FXMLLoader loader = new FXMLLoader(Main.class.getResource("updateAppointment-view.fxml"));
        Parent root = loader.load();
        UpdateAppointmentController updateAppointmentController = loader.getController();

        if (selectedRowWeek != null){
            String startParseWeek = selectedRowWeek.getStart();
            String endParseWeek = selectedRowWeek.getEnd();
            String startDateWeek = startParseWeek.substring(0,(startParseWeek.length()/2)+1);
            String startTimeWeek = startParseWeek.substring(((startParseWeek.length()/2)+1));
            String endDateWeek = endParseWeek.substring(0, (startParseWeek.length()/2)+1);
            String endTimeWeek = endParseWeek.substring(((startParseWeek.length()/2)+1), startParseWeek.length());
            updateAppointmentController.setAppointmentData(selectedRowWeek.getAppointment_ID(), selectedRowWeek.getTitle(), selectedRowWeek.getDescription(), selectedRowWeek.getLocation(), selectedRowWeek.getContact(), selectedRowWeek.getType(), startDateWeek, startTimeWeek, endDateWeek, endTimeWeek, selectedRowWeek.getCustomer_ID(), selectedRowWeek.getUser_ID());
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) mainMenuUpdateAppointmentBtn.getScene().getWindow();
            currentStage.close();}

        else if (selectedRowMonth != null){
            String startParseMonth = selectedRowMonth.getStart();
            String endParseMonth = selectedRowMonth.getEnd();
            String startDateMonth = startParseMonth.substring(0,(startParseMonth.length()/2)+1);
            String startTimeMonth = startParseMonth.substring(((startParseMonth.length()/2)+1));
            String localStartTimeMonth = startTimeMonth;
            String endDateMonth = endParseMonth.substring(0, (startParseMonth.length()/2)+1);
            String endTimeMonth = endParseMonth.substring(((startParseMonth.length()/2)+1), startParseMonth.length());
            String localEndTimeMonth = endTimeMonth;
            updateAppointmentController.setAppointmentData(selectedRowMonth.getAppointment_ID(), selectedRowMonth.getTitle(), selectedRowMonth.getDescription(), selectedRowMonth.getLocation(), selectedRowMonth.getContact(), selectedRowMonth.getType(), startDateMonth, localStartTimeMonth, endDateMonth, localEndTimeMonth, selectedRowMonth.getCustomer_ID(), selectedRowMonth.getUser_ID());
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) mainMenuUpdateAppointmentBtn.getScene().getWindow();
            currentStage.close();
        }
        else{
            showError("mainMenu.noAppointmentSelectedTitle", "mainMenu.noAppointmentSelectedMessage");
        }
    }

    public void onActionDeleteAppointment(ActionEvent actionEvent) throws SQLException {
        Appointment selectedRowWeek = mainMenuAppointmentsWeekTableView.getSelectionModel().getSelectedItem();
        Appointment selectedRowMonth = mainMenuAppointmentsMonthTableView.getSelectionModel().getSelectedItem();

        if(selectedRowWeek != null){

            showMessage(selectedRowWeek.getType() + " " + selectedRowWeek.getAppointment_ID().toString(), selectedRowWeek.getType() + " type appointment, with ID: " + selectedRowWeek.getAppointment_ID().toString() + " was cancelled.");
            AppointmentsQuery.deleteAppointment(selectedRowWeek.getAppointment_ID());
            onActionSelectDate(new ActionEvent());

        }
        else if(selectedRowMonth != null){
            showMessage(selectedRowMonth.getType() + " " + selectedRowMonth.getAppointment_ID().toString(), selectedRowMonth.getType() + " type appointment, with ID: " + selectedRowMonth.getAppointment_ID().toString() + " was cancelled.");
            AppointmentsQuery.deleteAppointment(selectedRowMonth.getAppointment_ID());
            onActionSelectDate(new ActionEvent());
        }
        else {
            showError("mainMenu.noAppointmentSelectedTitle", "mainMenu.noAppointmentSelectedMessage");
        }
    }

    private void showError(String title, String message){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(bundle.getString(title));
        alert.setContentText(bundle.getString(message));
        alert.showAndWait();
    }

    private void showMessage(String titleKey, String messageKey){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        String title = bundle.getString(titleKey);
        alert.setTitle(title);
        String message = bundle.getString(messageKey);
        alert.setContentText(message);
        alert.showAndWait();
    }


    public void onActionSelectDate(ActionEvent actionEvent) {
        LocalDate selectedDate = mainMenuScheduleDatePicker.getValue();
        if (selectedDate != null) {
            LocalDate monthStart = selectedDate.withDayOfMonth(1);
            LocalDate monthEnd = selectedDate.withDayOfMonth(selectedDate.lengthOfMonth());
            ResultSet rsMonth = AppointmentsQuery.accessDBAppointmentsMonthTable(monthStart, monthEnd);
            ObservableList<Appointment> monthAppointments = FXCollections.observableArrayList();
            try {
                while (rsMonth.next()) {

                    Integer appointmentID = rsMonth.getInt(1);
                    String Title = rsMonth.getString(2);
                    String Description = rsMonth.getString(3);
                    String Location = rsMonth.getString(4);
                    String Contact = rsMonth.getString(5);
                    String Type = rsMonth.getString(6);
                    String StartUTC = convertToUserTime(rsMonth.getString(7));
                    String EndUTC = convertToUserTime(rsMonth.getString(8));
                    String StartDateMonth = StartUTC.substring(0,(StartUTC.length()/2)+1);
                    String startTimeMonth = StartUTC.substring(((StartUTC.length()/2)+2));
                    String endDateMonth = EndUTC.substring(0, (StartUTC.length()/2)+1);
                    String endTimeMonth = EndUTC.substring(((StartUTC.length()/2)+2), StartUTC.length());
                    Integer Customer_ID = rsMonth.getInt(9);
                    Integer User_ID = rsMonth.getInt(10);

                    Appointment appointment = new Appointment(appointmentID, Title, Description, Location, Contact, Type, StartDateMonth+" "+startTimeMonth, endDateMonth+" "+endTimeMonth, Customer_ID, User_ID);
                    monthAppointments.add(appointment);
                }

                mainMenuAppointmentsMonthTableView.setItems(monthAppointments);
            } catch (SQLException e) {
                e.printStackTrace();
            }

            LocalDate weekStart = selectedDate.with(DayOfWeek.MONDAY);
            LocalDate weekEnd = selectedDate.with(DayOfWeek.SUNDAY);
            ResultSet rsWeek = AppointmentsQuery.accessDBAppointmentsWeekTable(weekStart, weekEnd);
            ObservableList<Appointment> weekAppointments = FXCollections.observableArrayList();

            try {
                while (rsWeek.next()) {

                    Integer appointmentID = rsWeek.getInt(1);
                    String Title = rsWeek.getString(2);
                    String Description = rsWeek.getString(3);
                    String Location = rsWeek.getString(4);
                    String Contact = rsWeek.getString(5);
                    String Type = rsWeek.getString(6);
                    String StartUTC = convertToUserTime(rsWeek.getString(7));
                    String EndUTC = convertToUserTime(rsWeek.getString(8));
                    String startDateWeek = StartUTC.substring(0,(StartUTC.length()/2)+1);
                    String startTimeWeek = StartUTC.substring(((StartUTC.length()/2)+2));
                    String endDateWeek = EndUTC.substring(0, (StartUTC.length()/2)+1);
                    String endTimeWeek = EndUTC.substring(((StartUTC.length()/2)+2), StartUTC.length());
                    Integer Customer_ID = rsWeek.getInt(9);
                    Integer User_ID = rsWeek.getInt(10);

                    Appointment appointment = new Appointment(appointmentID, Title, Description, Location, Contact, Type, startDateWeek+" "+startTimeWeek, endDateWeek+" "+endTimeWeek, Customer_ID, User_ID);
                    weekAppointments.add(appointment);
                }

                mainMenuAppointmentsWeekTableView.setItems(weekAppointments);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void onActionOpenReports(ActionEvent actionEvent) throws IOException {

        FXMLLoader loader = new FXMLLoader(Main.class.getResource("report-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) mainMenuReportBtn.getScene().getWindow();
        currentStage.close();

    }
}

