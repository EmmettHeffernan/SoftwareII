package heffernan.softwareii.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

import javax.xml.stream.Location;
import java.security.Timestamp;
import java.time.ZonedDateTime;

/**
 * The "Appointment" Class represents an appointment entity
 * It also provides methods for retrieving the appointments attributes
 */
public class Appointment {

    private final Integer Appointment_ID;
    private final String Title;
    private final String Description;
    private final String Location;
    private final String Contact;
    private final String Type;
    private final String Start;
    private final String End;
    private final Integer Customer_ID;
    private final Integer User_ID;

    /**
     * Constructs an "Appointment" object with the following parameters.
     *
     * @param Appointment_ID
     * @param Title
     * @param Description
     * @param Location
     * @param Contact
     * @param Type
     * @param Start
     * @param End
     * @param Customer_ID
     * @param User_ID
     */
    public Appointment(Integer Appointment_ID, String Title, String Description, String Location, String Contact, String Type, String Start, String End, Integer Customer_ID, Integer User_ID)
    {
        this.Appointment_ID = Appointment_ID;
        this.Title = Title;
        this.Description = Description;
        this.Location = Location;
        this.Contact = Contact;
        this.Type = Type;
        this.Start = Start;
        this.End = End;
        this.Customer_ID = Customer_ID;
        this.User_ID = User_ID;
    }

    /**
     * Gets the auto-generated unique key for the appointment
     * @return Appointment's primary key
     */
    public Integer getAppointment_ID() {
        return Appointment_ID;
    }

    /**
     * Gets the appointment title
     * @return Appointment's title
     */
    public String getTitle() {
        return Title;
    }

    /**
     * Gets the appointment description
     * @return Appointment's description
     */
    public String getDescription() {
        return Description;
    }

    /**
     * Gets the appointment location
     * @return Appointment's location
     */
    public String getLocation() {
        return Location;
    }

    /**
     * Gets the appointment type
     * @return Appointment's type
     */
    public String getType() {
        return Type;
    }

    /**
     * Gets the appointment contact representative
     * @return Appointment's contact
     */
    public String getContact() {
        return Contact;
    }

    /**
     * Gets the appointment start time
     * @return Appointment's start date and time
     */
    public String getStart() {
        return Start;
    }

    /**
     * Gets the appointment end time
     * @return Appointment's end date and time
     */
    public String getEnd() {
        return End;
    }

    /**
     * Gets the unique ID of the customer associated with the appointment
     * @return Customer's unique ID
     */
    public Integer getCustomer_ID() {
        return Customer_ID;
    }

    /**
     * Gets the unique ID of the user who set the appointment up
     * @return User's unique ID
     */
    public Integer getUser_ID() {
        return User_ID;
    }

}
