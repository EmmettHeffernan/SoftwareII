package heffernan.softwareii.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * The "ContactsScheduleTableRow" class represents a row of data for a contact's appointment schedule
 */
public class ContactsScheduleTableRow {
    private final IntegerProperty appointmentID;
    private final StringProperty title;
    private final StringProperty type;
    private final StringProperty description;
    private final StringProperty start;
    private final StringProperty end;
    private final IntegerProperty customerID;

    /**
     * Constructs a "ContactsScheduleTableRow" object with the following attributes.
     * @param appointmentID
     * @param title
     * @param type
     * @param description
     * @param start
     * @param end
     * @param customerID
     */
    public ContactsScheduleTableRow(Integer appointmentID, String title, String type, String description, String start, String end, Integer customerID) {
        this.appointmentID = new SimpleIntegerProperty(appointmentID);
        this.title = new SimpleStringProperty(title);
        this.type = new SimpleStringProperty(type);
        this.description = new SimpleStringProperty(description);
        this.start = new SimpleStringProperty(start);
        this.end = new SimpleStringProperty(end);
        this.customerID = new SimpleIntegerProperty(customerID);
    }

    /**
     * Gets the appointment ID
     * @return Appointment ID
     */
    public IntegerProperty getAppointmentID(){
        return appointmentID;
    }

    /**
     * Gets the appointment title
     * @return Appointment title
     */
    public StringProperty getTitle() {
        return title;
    }

    /**
     * Gets the appointment type
     * @return Appointment's type
     */
    public StringProperty getType() {
        return type;
    }

    /**
     * Gets the appointment location
     * @return Appointment's location
     */
    public StringProperty getDescription() {
        return description;
    }

    /**
     * Gets the appointment start time
     * @return Appointment's start date and time
     */
    public StringProperty getStart() {
        return start;
    }

    /**
     * Gets the appointment end time
     * @return Appointment's end date and time
     */
    public StringProperty getEnd() {
        return end;
    }

    /**
     * Gets the unique ID of the customer associated with the appointment
     * @return Customer's unique ID
     */
    public IntegerProperty getCustomerID() {
        return customerID;
    }

}
