package heffernan.softwareii.model;

import java.security.Timestamp;
import java.time.ZonedDateTime;

/**
 * The "FirstLevelDivision" class represents a division within a country
 */
public class FirstLevelDivision {

    private Integer Division_ID;
    private String Division;
    private ZonedDateTime Create_Date;
    private String Created_By;
    private Timestamp Last_Update;
    private String Last_Updated_By;

    /**
     * Constructs a "FirstLevelDivision" object with the following attributes.
     * @param Division_ID
     * @param Division
     * @param Create_Date
     * @param Created_By
     * @param Last_Update
     * @param Last_Updated_By
     * @param Country_ID
     */
    public FirstLevelDivision(Integer Division_ID, String Division, ZonedDateTime Create_Date, String Created_By, Timestamp Last_Update, String Last_Updated_By, Integer Country_ID)
    {

        this.Division_ID = Division_ID;
        this.Division = Division;
        this.Create_Date = Create_Date;
        this.Created_By = Created_By;
        this.Last_Update = Last_Update;
        this.Last_Updated_By = Last_Updated_By;

    }

}
