package heffernan.softwareii.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * The "CustomersReportTableRow" class represents a row in a report that displays the count of customers per country
 */
public class CustomersReportTableRow {
    private final StringProperty country;
    private final IntegerProperty customerCount;

    /**
     * Constructs a "CustomersReportTableRow" object with the following attributes
     * @param country
     * @param customerCount
     */
    public CustomersReportTableRow(String country, Integer customerCount) {
        this.country = new SimpleStringProperty(country);
        this.customerCount = new SimpleIntegerProperty(customerCount);
    }

    /**
     * Gets the name of the country
     * @return Country
     */
    public StringProperty getCountry(){
        return country;
    }

    /**
     * Gets the number of customers in the country
     * @return Count of customers
     */
    public IntegerProperty getCustomerCount(){
        return customerCount;
    }

}
