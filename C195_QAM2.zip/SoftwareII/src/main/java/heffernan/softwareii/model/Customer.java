package heffernan.softwareii.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Customer {

    private final Integer Customer_ID;
    private final String Customer_Name;
    private final String Address;
    private final String Postal_Code;
    private final String Phone;
    private final String Division;
    private final String Country;

    /**
     * The "Customer" class represents a customer entity with the following attributes.
     * @param Customer_ID
     * @param Customer_Name
     * @param Address
     * @param Postal_Code
     * @param Phone
     * @param Division
     * @param Country
     */
    public Customer(Integer Customer_ID, String Customer_Name, String Address, String Postal_Code, String Phone, String Division, String Country)
    {

        this.Customer_ID = Customer_ID;
        this.Customer_Name = Customer_Name;
        this.Address = Address;
        this.Postal_Code = Postal_Code;
        this.Phone = Phone;
        this.Division = Division;
        this.Country = Country;

    }

    /**
     * Gets the unique ID of the customer
     * @return Customer ID
     */
    public Integer getCustomer_ID() {
        return Customer_ID;
    }

    /**
     * Gets the name of the customer.
     * @return Customer name
     */
    public String getCustomer_Name() {
        return Customer_Name;
    }

    /**
     * Gets the address of the customer
     * @return Customer address
     */
    public String getAddress() {
        return Address;
    }

    /**
     * Gets the postal code of the customer
     * @return Postal code
     */
    public String getPostal_Code() {
        return Postal_Code;
    }

    /**
     * Gets the phone number of the customer.
     * @return Phone number
     */
    public String getPhone() {
        return Phone;
    }

    /**
     * Gets the division (region, state, province) to which the customer belongs
     * @return Division name
     */
    public String getDivision() {
        return Division;
    }

    /**
     * Gets the country where the customer is located
     * @return Country
     */
    public String getCountry(){
        return Country;
    }
}
