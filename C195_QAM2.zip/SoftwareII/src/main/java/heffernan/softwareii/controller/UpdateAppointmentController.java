package heffernan.softwareii.controller;

import heffernan.softwareii.Main;
import heffernan.softwareii.helper.AppointmentsQuery;
import heffernan.softwareii.helper.ContactsQuery;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

public class UpdateAppointmentController {

    @FXML
    private TextField updateAppointmentLocationTxt;

    @FXML
    private DatePicker updateAppointmentStartDate;

    @FXML
    private DatePicker updateAppointmentEndDate;

    @FXML
    private ComboBox updateAppointmentStartTime;

    @FXML
    private ComboBox updateAppointmentEndTime;

    @FXML
    private TextField updateAppointmentIDTxt;

    @FXML
    private TextField updateAppointmentTitleTxt;

    @FXML
    private TextField updateAppointmentDescriptionTxt;

    @FXML
    private ComboBox<String> updateAppointmentContactCombo;

    @FXML
    private TextField updateAppointmentTypeTxt;

    @FXML
    private TextField updateAppointmentCustomerIDTxt;

    @FXML
    private TextField updateAppointmentUserIDTxt;

    @FXML
    private Button updateAppointmentSaveBtn;

    @FXML
    private Button updateAppointmentCancelBtn;

    private ResourceBundle bundle;

    @FXML
    void initialize(){
        Locale locale = Locale.getDefault();
        bundle = ResourceBundle.getBundle("lang", locale);
        setUpdateAppointmentContactCombo();
        setUpdateAppointmentTimes();
    }

    @FXML
    void onActionSave(ActionEvent actionEvent) throws IOException, SQLException {
        Integer appointmentID = Integer.parseInt(updateAppointmentIDTxt.getText());
        String title = updateAppointmentTitleTxt.getText();
        String description = updateAppointmentDescriptionTxt.getText();
        String location = updateAppointmentLocationTxt.getText();
        String contact = updateAppointmentContactCombo.getValue();
        String type = updateAppointmentTypeTxt.getText();
        LocalDate startDate = updateAppointmentStartDate.getValue();
        Object startTime = updateAppointmentStartTime.getValue();
        LocalDate endDate = updateAppointmentEndDate.getValue();
        Object endTime = updateAppointmentEndTime.getValue();
        String customerID = updateAppointmentCustomerIDTxt.getText();
        String userID = updateAppointmentUserIDTxt.getText();

        if(title.isEmpty() || title.length() > 50 || description.isEmpty() || description.length() > 50 || location.isEmpty() || location.length() > 50 ||
                (contact == null) || type.isEmpty() || type.length() > 50 || startDate == null || startTime == null || endDate == null || endTime == null || customerID.isEmpty() || userID.isEmpty()){
            showError("addAppointment.SaveErrorTitle", "addAppointment.SaveErrorMessage");
            return;
        }
        else if(!isDuringBusinessOperation(startDate.toString(), startTime.toString(), endDate.toString(), endTime.toString())){
            showError("addAppointment.OutsideBusinessHoursTitle", "addAppointment.OutsideBusinessHoursMessage");
            return;
        }
        else if(hasOverlap(Integer.parseInt(customerID), startDate.toString(), startTime.toString(), endDate.toString(), endTime.toString())){
            showError("addAppointment.scheduleConflictTitle", "addAppointment.scheduleConflictMessage");
            return;
        }

        AppointmentsQuery.updateAppointment(appointmentID, title, description, location, contact, type,
                convertToUTCDateTime(startDate.toString(), startTime.toString()), convertToUTCDateTime(endDate.toString(),
                        endTime.toString()), Integer.parseInt(customerID), Integer.parseInt(userID));

        FXMLLoader loader = new FXMLLoader(Main.class.getResource("mainMenu-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) updateAppointmentCancelBtn.getScene().getWindow();
        currentStage.close();
    }

    @FXML
    void onActionCancel(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("mainMenu-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) updateAppointmentCancelBtn.getScene().getWindow();
        currentStage.close();
    }

    private void setUpdateAppointmentContactCombo() {
        ResultSet contacts = ContactsQuery.selectContacts();
        try {
            while (contacts.next()) {
                String contactName = contacts.getString(1);
                updateAppointmentContactCombo.getItems().add(contactName);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void setUpdateAppointmentTimes(){
        List<String> hours = Arrays.asList("00:00:00", "01:00:00", "02:00:00", "03:00:00", "04:00:00", "05:00:00", "06:00:00", "07:00:00", "08:00:00", "09:00:00", "10:00:00", "11:00:00",
                "12:00:00", "13:00:00", "14:00:00", "15:00:00", "16:00:00", "17:00:00", "18:00:00", "19:00:00","20:00:00", "21:00:00", "22:00:00", "23:00:00");
        updateAppointmentStartTime.getItems().addAll(hours);
        updateAppointmentEndTime.getItems().addAll(hours);
    }

    public void setAppointmentData(Integer ID, String Title, String Description, String Location, String Contact, String Type, String StartDate, String StartTime, String EndDate, String EndTime, Integer Customer_ID, Integer User_ID){
        updateAppointmentIDTxt.setText(ID.toString());
        updateAppointmentTitleTxt.setText(Title);
        updateAppointmentDescriptionTxt.setText(Description);
        updateAppointmentLocationTxt.setText(Location);
        updateAppointmentContactCombo.setValue(Contact);
        updateAppointmentTypeTxt.setText(Type);
        updateAppointmentStartDate.setValue(LocalDate.parse(StartDate));
        updateAppointmentStartTime.setValue(StartTime);
        updateAppointmentEndDate.setValue(LocalDate.parse(EndDate));
        updateAppointmentEndTime.setValue(EndTime);
        updateAppointmentCustomerIDTxt.setText(Customer_ID.toString());
        updateAppointmentUserIDTxt.setText(User_ID.toString());
    }

    private String convertToUTCDateTime(String localDate, String localTime) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime localDateTime = LocalDateTime.parse(localDate.trim() + " " + localTime.trim(), dateTimeFormatter);
        ZoneId zoneId = ZoneId.of("UTC");
        ZonedDateTime localZonedDateTime = localDateTime.atZone(ZoneId.systemDefault());
        ZonedDateTime utcDateTime = localZonedDateTime.withZoneSameInstant(zoneId);
        return utcDateTime.format(dateTimeFormatter);
    }

    private boolean isDuringBusinessOperation(String startDate, String startTime, String endDate, String endTime){
        ZoneId etZone = ZoneId.of("America/New_York");
        LocalDateTime startDateTime = LocalDateTime.parse(startDate+"T"+startTime.trim());
        LocalDateTime endDateTime = LocalDateTime.parse(endDate+"T"+endTime.trim());
        ZonedDateTime startET = startDateTime.atZone(ZoneId.systemDefault()).withZoneSameInstant(etZone);
        ZonedDateTime endET = endDateTime.atZone(ZoneId.systemDefault()).withZoneSameInstant(etZone);
        LocalTime businessOpen = LocalTime.of(8, 0);
        LocalTime businessClose = LocalTime.of(22, 0);
        return !startET.toLocalTime().isBefore(businessOpen) && !endET.toLocalTime().isAfter(businessClose) &&
                (startET.getDayOfWeek() != DayOfWeek.SATURDAY && startET.getDayOfWeek() != DayOfWeek.SUNDAY) &&
                (endET.getDayOfWeek() != DayOfWeek.SATURDAY && endET.getDayOfWeek() != DayOfWeek.SUNDAY);
    }

    private boolean hasOverlap(int customerID, String startDate, String startTime, String endDate, String endTime) throws SQLException {
        ResultSet rs = AppointmentsQuery.getCustomerScheduledAppointments(customerID);
        while(rs.next()){
            String scheduledStart = rs.getString(1);
            String scheduledEnd = rs.getString(2);
            LocalDateTime scheduledStartTime = LocalDateTime.parse(scheduledStart, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            LocalDateTime scheduledEndTime = LocalDateTime.parse(scheduledEnd, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            LocalDateTime newStartTime = LocalDateTime.parse(convertToUTCDateTime(startDate, startTime), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            LocalDateTime newEndTime = LocalDateTime.parse(convertToUTCDateTime(endDate, endTime), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

            if ((newStartTime.isBefore(scheduledEndTime)) && newEndTime.isAfter(scheduledStartTime)) {
                return true;
            }
        }
        return false;
    }

    private void showError(String title, String message){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(bundle.getString(title));
        alert.setContentText(bundle.getString(message));
        alert.showAndWait();
    }

}
