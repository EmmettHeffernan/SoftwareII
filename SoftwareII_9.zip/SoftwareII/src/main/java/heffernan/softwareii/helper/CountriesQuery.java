package heffernan.softwareii.helper;

import java.sql.*;

public class CountriesQuery {

    public static ResultSet accessDBCountriesTable() {
        Connection connection;
        connection = JDBC.connection;
        ResultSet rs = null;

        try{

            String sql = "SELECT * FROM countries";
            PreparedStatement ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

}
