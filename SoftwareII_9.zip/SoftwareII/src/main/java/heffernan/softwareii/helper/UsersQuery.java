package heffernan.softwareii.helper;

import java.sql.*;

public class UsersQuery {

    public static ResultSet accessDBUsersTable() {
        Connection connection;
        connection = JDBC.connection;
        ResultSet rs = null;

        try{

            String sql = "SELECT users.User_Name, users.Password FROM users";
            PreparedStatement ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

}
