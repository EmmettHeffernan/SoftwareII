package heffernan.softwareii.helper;

import java.sql.*;

public abstract class CustomersQuery {

    public static void insertAddCustomer(String Customer_Name, String Address, String Postal_Code, String Phone, String first_level_division) throws SQLException {
        Integer fldID = null;
        ResultSet rs = First_Level_DivisionsQuery.accessDBFLDTableDivID(first_level_division);

        while(rs.next()){
            fldID = rs.getInt(1); 
        }

        String sql = "INSERT INTO CUSTOMERS (Customer_ID, Customer_Name, Address, Postal_Code, Phone, Create_Date, Created_By, Last_Update, Last_Updated_By, Division_ID) " +
                "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, getNextCustomerID());
        ps.setString(2, Customer_Name);
        ps.setString(3, Address);
        ps.setString(4, Postal_Code);
        ps.setString(5, Phone);
        Timestamp create_date = new Timestamp(System.currentTimeMillis());
        ps.setTimestamp(6, create_date);
        ps.setString(7, "script");
        ps.setTimestamp(8, create_date);
        ps.setString(9, "script");
        ps.setInt(10, fldID);



        int rowsAffected = ps.executeUpdate();
    }

    public static int updateCustomer(int customerID, String customerName, String address, String postalCode, String Phone, String firstLevelDivision) throws SQLException {
        Connection connection;
        connection = JDBC.connection;
        ResultSet rs = null;
        Integer fldID = null;
        rs = First_Level_DivisionsQuery.accessDBFLDTableDivID(firstLevelDivision);
        while(rs.next()){
            fldID = rs.getInt(1);
        }
        String sql = "UPDATE customers SET Customer_Name = ?, Address = ?, Postal_Code = ?, Phone = ?, Last_Update = ?, Last_Updated_By = ?, Division_ID = ? WHERE Customer_ID = ?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, customerName);
        ps.setString(2, address);
        ps.setString(3, postalCode);
        ps.setString(4, Phone);
        Timestamp update_date = new Timestamp(System.currentTimeMillis());
        ps.setTimestamp(5, update_date);
        ps.setString(6, "script");
        ps.setInt(7, fldID);
        ps.setInt(8, customerID);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    public static ResultSet accessDBCustomersTable() {
        Connection connection;
        connection = JDBC.connection;
        ResultSet rs = null;

        try{

            String sql = "SELECT customers.Customer_ID, customers.Customer_Name, customers.Address, customers.Postal_Code, customers.Phone, first_level_divisions.Division, countries.Country FROM ((customers INNER JOIN first_level_divisions ON customers.Division_ID = first_level_divisions.Division_ID) INNER JOIN countries ON first_level_divisions.Country_ID = countries.Country_ID)";
            PreparedStatement ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

    public static int deleteCustomer(int customerID) throws SQLException {
        Connection connection;
        connection = JDBC.connection;
        String sql = "DELETE FROM customers WHERE Customer_ID = ?";
        PreparedStatement ps = connection.prepareStatement(sql);
        try(ps){
            ps.setInt(1, customerID);
            return ps.executeUpdate();
        }
    }

    public static int getNextCustomerID() throws SQLException {
        Connection connection;
        connection = JDBC.connection;
        String sql = "SELECT MAX(Customer_ID) FROM customers";
        PreparedStatement ps = connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            int maxID = rs.getInt(1);
            return maxID + 1;
        } else {
            return 1;
        }
    }

}
