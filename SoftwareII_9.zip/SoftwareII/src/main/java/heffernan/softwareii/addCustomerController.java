package heffernan.softwareii;


import heffernan.softwareii.helper.AppointmentsQuery;
import heffernan.softwareii.helper.CountriesQuery;
import heffernan.softwareii.helper.CustomersQuery;
import heffernan.softwareii.helper.First_Level_DivisionsQuery;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

public class addCustomerController {


    @FXML
    private TextField addCustomerIDTxt;

    @FXML
    private TextField addCustomerNameTxt;

    @FXML
    private TextField addCustomerAddressTxt;

    @FXML
    private TextField addCustomerPostalCodeTxt;

    @FXML
    private ComboBox<String> addCustomerCountryCombo;

    @FXML
    private ComboBox<String> addCustomerFLDCombo;

    @FXML
    private TextField addCustomerPhoneTxt;

    @FXML
    private Button addCustomerSaveBtn;

    @FXML
    private Button addCustomerCancelBtn;

    @FXML
    void initialize() throws SQLException {
        setAddCustomerCountryCombo();
        addCustomerIDTxt.setText(String.valueOf(CustomersQuery.getNextCustomerID()));
    }

    private void setAddCustomerCountryCombo() {
        ResultSet countries = CountriesQuery.accessDBCountriesTable();
        try {
            while (countries.next()){
                String countryName = countries.getString(2);
                addCustomerCountryCombo.getItems().add(countryName);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    private void setAddCustomerFLDCombo(String country) {
        addCustomerFLDCombo.getItems().clear();
        ResultSet divisions = First_Level_DivisionsQuery.accessDBFLDTable(country);
        try {
            while (divisions.next()) {
                String divisionCountry = divisions.getString(2);

                if (divisionCountry.equals(country)) {
                    String division = divisions.getString(1);
                    addCustomerFLDCombo.getItems().add(division);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



    @FXML
    void onActionSave(ActionEvent actionEvent) throws IOException, SQLException {

        String customerName = addCustomerNameTxt.getText();
        String customerAddress = addCustomerAddressTxt.getText();
        String customerPostal = addCustomerPostalCodeTxt.getText();
        String customerPhone = addCustomerPhoneTxt.getText();
        String customerCountry = addCustomerCountryCombo.getValue();
        String customerFLD = addCustomerFLDCombo.getValue();

        if (customerName.isEmpty() || customerAddress.isEmpty() || customerPostal.isEmpty() || customerPhone.isEmpty() || customerCountry.isEmpty() || customerFLD.isEmpty()
        || customerName.length() > 50 || customerAddress.length() > 100 || customerPostal.length() > 50 || customerPhone.length() > 50){
            showError("addCustomer.SaveErrorTitle","addCustomer.SaveErrorMessage");
            return;
        }

        CustomersQuery.insertAddCustomer(customerName, customerAddress, customerPostal, customerPhone, customerFLD);

        FXMLLoader loader = new FXMLLoader(Main.class.getResource("mainMenu-view.fxml"));
        Parent root = loader.load();

        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) addCustomerSaveBtn.getScene().getWindow();
        currentStage.close();
    }

    @FXML
    void onActionCancel(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("mainMenu-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) addCustomerCancelBtn.getScene().getWindow();
        currentStage.close();
    }

    public void onActionSelect(ActionEvent actionEvent) {
        String selectedCountry = addCustomerCountryCombo.getSelectionModel().getSelectedItem();
        setAddCustomerFLDCombo(selectedCountry);
    }

    private void showError(String title, String message){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

}
