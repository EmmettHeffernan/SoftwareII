package heffernan.softwareii;

import java.security.Timestamp;
import java.time.ZonedDateTime;

public class FirstLevelDivision {

    private Integer Division_ID;
    private String Division;
    private ZonedDateTime Create_Date;
    private String Created_By;
    private Timestamp Last_Update;
    private String Last_Updated_By;

    public FirstLevelDivision(Integer Division_ID, String Division, ZonedDateTime Create_Date, String Created_By, Timestamp Last_Update, String Last_Updated_By, Integer Country_ID)
    {

        this.Division_ID = Division_ID;
        this.Division = Division;
        this.Create_Date = Create_Date;
        this.Created_By = Created_By;
        this.Last_Update = Last_Update;
        this.Last_Updated_By = Last_Updated_By;

    }

}
