package heffernan.softwareii;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;

public class LoginController implements Initializable {

    Stage stage;
    Parent scene;

    private ResourceBundle bundle;

    @FXML
    private TextField loginUsernameTxtField;

    @FXML
    private PasswordField loginPasswordTxtField;

    @FXML
    private TextField loginZoneIDTxtField;

    @FXML
    private Button loginLoginBtn;

    @FXML
    void onActionLogin(ActionEvent Event) throws IOException {

        FXMLLoader loader = new FXMLLoader(Main.class.getResource("mainMenu-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) loginLoginBtn.getScene().getWindow();
        currentStage.close();

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Locale locale = Locale.getDefault();
        bundle = ResourceBundle.getBundle("lang", locale);
    }
}