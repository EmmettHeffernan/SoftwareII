module heffernan.softwareii {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens heffernan.softwareii to javafx.fxml;
    exports heffernan.softwareii;
}