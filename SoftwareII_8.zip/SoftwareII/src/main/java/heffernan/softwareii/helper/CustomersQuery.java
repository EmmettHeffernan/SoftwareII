package heffernan.softwareii.helper;

import java.sql.*;

public abstract class CustomersQuery {

    public static int insertAddCustomer(String Customer_Name, String Address, String Postal_Code, String Phone, String first_level_division) throws SQLException {
        Integer fldID = null;
        ResultSet rs = First_Level_DivisionsQuery.accessDBFLDTableDivID(first_level_division);
        while(rs.next()){
            fldID = rs.getInt(1); 
        }

        String sql = "INSERT INTO CUSTOMERS (Customer_Name, Address, Postal_Code, Phone, Create_Date, Created_By, Last_Update, Last_Updated_By, Division_ID) " +
                "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";

        PreparedStatement ps = JDBC.connection.prepareStatement(sql);

        ps.setString(1, Customer_Name);
        ps.setString(2, Address);
        ps.setString(3, Postal_Code);
        ps.setString(4, Phone);
        Timestamp create_date = new Timestamp(System.currentTimeMillis());
        ps.setTimestamp(5, create_date);
        ps.setString(6, "script");
        ps.setTimestamp(7, create_date);
        ps.setString(8, "script");
        ps.setInt(9, fldID);



        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    public static ResultSet accessDBCustomersTable() {
        Connection connection;
        connection = JDBC.connection;
        ResultSet rs = null;

        try{

            String sql = "SELECT customers.Customer_ID, customers.Customer_Name, customers.Address, customers.Postal_Code, customers.Phone, first_level_divisions.Division, countries.Country FROM ((customers INNER JOIN first_level_divisions ON customers.Division_ID = first_level_divisions.Division_ID) INNER JOIN countries ON first_level_divisions.Country_ID = countries.Country_ID)";
            PreparedStatement ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }



}
