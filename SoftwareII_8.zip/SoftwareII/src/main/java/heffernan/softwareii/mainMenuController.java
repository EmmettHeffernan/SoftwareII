package heffernan.softwareii;
import heffernan.softwareii.helper.AppointmentsQuery;
import heffernan.softwareii.helper.CustomersQuery;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class mainMenuController implements Initializable {

    @FXML
    private TableColumn<CustomersTableRow, Integer> customersTableIDCol;

    @FXML
    private TableColumn<CustomersTableRow, String> customersTableNameCol;

    @FXML
    private TableColumn<CustomersTableRow, String> customersTableAddressCol;

    @FXML
    private TableColumn<CustomersTableRow, String> customersTablePostalCodeCol;

    @FXML
    private TableColumn<CustomersTableRow, String> customersTablePhoneCol;

    @FXML
    private TableColumn<CustomersTableRow, String> customersTableStateCol;

    @FXML
    private TableColumn<CustomersTableRow, String> customersTableCountryCol;

    @FXML
    private TableView<CustomersTableRow> mainMenuCustomersTableView;

    @FXML
    private TableView<AppointmentsTableRow> mainMenuAppointmentsTableView;

    @FXML
    private TableColumn<AppointmentsTableRow, Integer> appointmentsTableIDCol;

    @FXML
    private TableColumn<AppointmentsTableRow, String> appointmentsTableTitleCol;

    @FXML
    private TableColumn<AppointmentsTableRow, String> appointmentsTableDescriptionCol;

    @FXML
    private TableColumn<AppointmentsTableRow, String> appointmentsTableLocationCol;

    @FXML
    private TableColumn<AppointmentsTableRow, String> appointmentsTableContactCol;

    @FXML
    private TableColumn<AppointmentsTableRow, String> appointmentsTableTypeCol;

    @FXML
    private TableColumn<AppointmentsTableRow, String> appointmentsTableStartCol;

    @FXML
    private TableColumn<AppointmentsTableRow, String> appointmentsTableEndCol;

    @FXML
    private TableColumn<AppointmentsTableRow, Integer> appointmentsTableCusIDCol;

    @FXML
    private TableColumn<AppointmentsTableRow, Integer> appoinmentsTableUserIDCol;

    @FXML
    private Button mainMenuAddCustomerBtn;

    @FXML
    private Button mainMenuUpdateCustomerBtn;

    @FXML
    private Button mainMenuCustomerDelete;

    @FXML
    private Button mainMenuAppointmentAddBtn;

    @FXML
    private Button mainMenuUpdateAppointmentBtn;

    @FXML
    private Button mainMenuDeleteAppointmentBtn;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        ObservableList<CustomersTableRow> customerList = FXCollections.observableArrayList();
        ObservableList<AppointmentsTableRow> appointmentList = FXCollections.observableArrayList();
        ResultSet rsCustomers = CustomersQuery.accessDBCustomersTable();
        ResultSet rsAppointments = AppointmentsQuery.accessDBAppointmentsTable();

        customersTableIDCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getCustomer_ID();
        });
        customersTableNameCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getCustomer_name();
        });
        customersTableAddressCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getAddress();
        });
        customersTablePostalCodeCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getPostal_code();
        });
        customersTablePhoneCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getPhone();
        });

        customersTableStateCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getState();
        });
        customersTableCountryCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getCountry();
        });

        appointmentsTableIDCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getAppointment_ID();
        });

        appointmentsTableTitleCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getTitle();
        });

        appointmentsTableDescriptionCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getDescription();
        });

        appointmentsTableLocationCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getLocation();
        });

        appointmentsTableContactCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getContact();
        });

        appointmentsTableTypeCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getType();
        });

        appointmentsTableStartCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getStart();
        });

        appointmentsTableEndCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getEnd();
        });

        appointmentsTableCusIDCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getCustomer_ID();
        });

        appoinmentsTableUserIDCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getUser_ID();
        });

        try{
            while (rsCustomers.next()) {

                Integer customerID = rsCustomers.getInt(1);
                String customerName = rsCustomers.getString(2);
                String customerAddress = rsCustomers.getString(3);
                String customerPostal = rsCustomers.getString(4);
                String customerPhone = rsCustomers.getString(5);
                String customerState = rsCustomers.getString(6);
                String customerCountry = rsCustomers.getString(7);

                CustomersTableRow ctr = new CustomersTableRow(
                        new ReadOnlyObjectWrapper(customerID),
                        new ReadOnlyStringWrapper(customerName),
                        new ReadOnlyStringWrapper(customerAddress),
                        new ReadOnlyStringWrapper(customerPostal),
                        new ReadOnlyStringWrapper(customerPhone),
                        new ReadOnlyStringWrapper(customerState),
                        new ReadOnlyStringWrapper(customerCountry));
                customerList.add(ctr);
            }

            mainMenuCustomersTableView.setItems(customerList);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        try{
            while (rsAppointments.next()) {

                Integer appointmentID = rsAppointments.getInt(1);
                String Title = rsAppointments.getString(2);
                String Description = rsAppointments.getString(3);
                String Location = rsAppointments.getString(4);
                String Contact = rsAppointments.getString(5);
                String Type = rsAppointments.getString(6);
                String Start = rsAppointments.getString(7);
                String End = rsAppointments.getString(8);
                Integer Customer_ID = rsAppointments.getInt(9);
                Integer User_ID = rsAppointments.getInt(10);


                AppointmentsTableRow atr = new AppointmentsTableRow(
                        new ReadOnlyObjectWrapper(appointmentID),
                        new ReadOnlyStringWrapper(Title),
                        new ReadOnlyStringWrapper(Description),
                        new ReadOnlyStringWrapper(Location),
                        new ReadOnlyStringWrapper(Contact),
                        new ReadOnlyStringWrapper(Type),
                        new ReadOnlyStringWrapper(Start),
                        new ReadOnlyStringWrapper(End),
                        new ReadOnlyObjectWrapper(Customer_ID),
                        new ReadOnlyObjectWrapper(User_ID));
                appointmentList.add(atr);
            }

            mainMenuAppointmentsTableView.setItems(appointmentList);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void onActionAddCustomer(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("addCustomer-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) mainMenuAddCustomerBtn.getScene().getWindow();
        currentStage.close();
    }

    public void onActionUpdateCustomer(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("updateCustomer-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) mainMenuAddCustomerBtn.getScene().getWindow();
        currentStage.close();
    }

    public void onActionDeleteCustomer(ActionEvent actionEvent) {
    }

    public void onActionAddAppointment(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("addAppointment-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) mainMenuAddCustomerBtn.getScene().getWindow();
        currentStage.close();
    }

    public void onActionUpdateAppointment(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("updateAppointment-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) mainMenuAddCustomerBtn.getScene().getWindow();
        currentStage.close();
    }

    public void onActionDeleteAppointment(ActionEvent actionEvent) {
    }
}
