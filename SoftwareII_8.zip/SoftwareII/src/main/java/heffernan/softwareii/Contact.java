package heffernan.softwareii;

public class Contact {

    private Integer Contact_ID;
    private String Contact_Name;
    private String Email;

    public Contact(Integer Contact_ID, String Contact_Name, String Email)
    {
        this.Contact_ID =  Contact_ID;
        this.Contact_Name = Contact_Name;
        this.Email = Email;
    }

}
