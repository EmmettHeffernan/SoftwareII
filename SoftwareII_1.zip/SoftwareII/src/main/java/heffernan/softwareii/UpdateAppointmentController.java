package heffernan.softwareii;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class UpdateAppointmentController {

    @FXML
    private TextField updateAppointmentIDTxt;

    @FXML
    private TextField updateAppointmentTitleTxt;

    @FXML
    private TextField updateAppointmentDescriptionTxt;

    @FXML
    private ComboBox updateAppointmentContactCombo;

    @FXML
    private TextField updateAppointmentTypeTxt;

    @FXML
    private DatePicker updateAppointmentStartDateTime;

    @FXML
    private DatePicker updateAppointmentEndDateTime;

    @FXML
    private TextField updateAppointmentCustomerIDTxt;

    @FXML
    private TextField updateAppointmentUserIDTxt;

    @FXML
    private Button updateAppointmentSaveBtn;

    @FXML
    private Button updateAppointmentCancelBtn;

    @FXML
    void onActionSave(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("mainMenu-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) updateAppointmentCancelBtn.getScene().getWindow();
        currentStage.close();
    }

    @FXML
    void onActionCancel(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("mainMenu-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) updateAppointmentCancelBtn.getScene().getWindow();
        currentStage.close();
    }
}
