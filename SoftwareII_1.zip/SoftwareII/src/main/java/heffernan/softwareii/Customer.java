package heffernan.softwareii;

import java.security.Timestamp;
import java.time.ZonedDateTime;

public class Customer {

    private Integer Customer_ID;
    private String Customer_Name;
    private String Address;
    private String Postal_Code;
    private String Phone;
    private ZonedDateTime Create_Date;
    private String Created_By;
    private Timestamp Last_Update;
    private String Last_Updated_By;
    private Integer Divsion_ID;

    public Customer(Integer Customer_ID, String Customer_Name, String Address, String Postal_Code, String Phone, ZonedDateTime Create_Date, String Created_By, Timestamp Last_Update, String Last_Updated_By, Integer Division_ID)
    {

        this.Customer_ID = Customer_ID;
        this.Customer_Name = Customer_Name;
        this.Address = Address;
        this.Postal_Code = Postal_Code;
        this.Phone = Phone;
        this.Create_Date = Create_Date;
        this.Created_By = Created_By;
        this.Last_Update = Last_Update;
        this.Last_Updated_By = Last_Updated_By;
        this.Divsion_ID = Division_ID;

    }

}
