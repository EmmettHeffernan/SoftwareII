package heffernan.softwareii;

import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableArray;
import javafx.collections.ObservableList;

import java.time.LocalDateTime;


public class AppointmentsTableRow {

    private ObservableValue<Integer> appointment_ID;
    private ObservableValue<String> title;
    private ObservableValue<String> description;
    private ObservableValue<String> location;
    private ObservableValue<String> contact;
    private ObservableValue<String> type;
    private ObservableValue<LocalDateTime> start;
    private ObservableValue<LocalDateTime> end;
    private ObservableValue<Integer> customer_ID;
    private ObservableValue<Integer> user_ID;

    public AppointmentsTableRow(ObservableValue<Integer> appointment_ID, ObservableValue<String> title, ObservableValue<String> description, ObservableValue<String> location, ObservableValue<String> contact, ObservableValue<String> type, ObservableValue<LocalDateTime> start, ObservableValue<LocalDateTime> end, ObservableValue<Integer> customer_ID, ObservableValue<Integer> user_ID){
        this.appointment_ID = appointment_ID;
        this.title = title;
        this.description = description;
        this.location = location;
        this.contact = contact;
        this.type = type;
        this.start = start;
        this.end = end;
        this.customer_ID = customer_ID;
        this.user_ID = user_ID;
    }

    public ObservableValue<Integer> getAppointment_ID() {return appointment_ID;}

    public ObservableValue<String> getTitle() {return title;}

    public ObservableValue<String> getDescription() {return description;}

    public ObservableValue<String> getLocation() {return location;}

    public ObservableValue<String> getContact() {return contact;}

    public ObservableValue<String> getType() {return type;}

    public ObservableValue<LocalDateTime> getStart() {return start;}

    public ObservableValue<LocalDateTime> getEnd() {return end;}

    public ObservableValue<Integer> getCustomer_ID() {return customer_ID;}

    public ObservableValue<Integer> getUser_ID() {return user_ID;}

}
