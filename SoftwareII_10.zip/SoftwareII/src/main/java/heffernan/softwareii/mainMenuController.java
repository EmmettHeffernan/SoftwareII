package heffernan.softwareii;
import heffernan.softwareii.helper.AppointmentsQuery;
import heffernan.softwareii.helper.CustomersQuery;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

public class mainMenuController implements Initializable {

    @FXML
    private Tab mainMenuAppointmentWeekTab;

    @FXML
    private TableView<Appointment> mainMenuAppointmentsWeekTableView;

    @FXML
    private TableColumn<Appointment, Integer> appointmentsWeekTableIDCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsWeekTableTitleCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsWeekTableDescriptionCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsWeekTableLocationCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsWeekTableContactCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsWeekTableTypeCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsWeekTableStartCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsWeekTableEndCol;

    @FXML
    private TableColumn<Appointment, Integer> appointmentsWeekTableCusIDCol;

    @FXML
    private TableColumn<Appointment, Integer> appoinmentsWeekTableUserIDCol;

    @FXML
    private Tab mainMenuAppointmentsMonthTab;

    @FXML
    private TableView<Appointment> mainMenuAppointmentsMonthTableView;

    @FXML
    private TableColumn<Appointment, Integer> appointmentsMonthTableIDCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsMonthTableTitleCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsMonthTableDescriptionCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsMonthTableLocationCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsMonthTableContactCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsMonthTableTypeCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsMonthTableStartCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsMonthTableEndCol;

    @FXML
    private TableColumn<Appointment, Integer> appointmentsMonthTableCusIDCol;

    @FXML
    private TableColumn<Appointment, Integer> appoinmentsMonthTableUserIDCol;

    @FXML
    private  DatePicker mainMenuScheduleDatePicker;

    @FXML
    private TableColumn<Customer, Integer> customersTableIDCol;

    @FXML
    private TableColumn<Customer, String> customersTableNameCol;

    @FXML
    private TableColumn<Customer, String> customersTableAddressCol;

    @FXML
    private TableColumn<Customer, String> customersTablePostalCodeCol;

    @FXML
    private TableColumn<Customer, String> customersTablePhoneCol;

    @FXML
    private TableColumn<Customer, String> customersTableStateCol;

    @FXML
    private TableColumn<Country, String> customersTableCountryCol;

    @FXML
    private TableView<Customer> mainMenuCustomersTableView;

    @FXML
    private TableView<Appointment> mainMenuAppointmentsTableView;

    @FXML
    private TableColumn<Appointment, Integer> appointmentsTableIDCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsTableTitleCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsTableDescriptionCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsTableLocationCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsTableContactCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsTableTypeCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsTableStartCol;

    @FXML
    private TableColumn<Appointment, String> appointmentsTableEndCol;

    @FXML
    private TableColumn<Appointment, Integer> appointmentsTableCusIDCol;

    @FXML
    private TableColumn<Appointment, Integer> appoinmentsTableUserIDCol;

    @FXML
    private Button mainMenuAddCustomerBtn;

    @FXML
    private Button mainMenuUpdateCustomerBtn;

    @FXML
    private Button mainMenuCustomerDelete;

    @FXML
    private Button mainMenuAppointmentAddBtn;

    @FXML
    private Button mainMenuUpdateAppointmentBtn;

    @FXML
    private Button mainMenuDeleteAppointmentBtn;

    private ZoneId userZoneID;

    public void setUserZoneID(ZoneId userZoneID){
        this.userZoneID = userZoneID;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        ObservableList<Customer> customers = FXCollections.observableArrayList();
        ObservableList<Appointment> appointments = FXCollections.observableArrayList();
        ResultSet rsCustomers = CustomersQuery.accessDBCustomersTable();
        ResultSet rsAppointments = AppointmentsQuery.accessDBAppointmentsTable();

        customersTableIDCol.setCellValueFactory(new PropertyValueFactory<>("Customer_ID"));
        customersTableNameCol.setCellValueFactory(new PropertyValueFactory<>("Customer_Name"));
        customersTableAddressCol.setCellValueFactory(new PropertyValueFactory<>("Address"));
        customersTablePostalCodeCol.setCellValueFactory(new PropertyValueFactory<>("Postal_Code"));
        customersTablePhoneCol.setCellValueFactory(new PropertyValueFactory<>("Phone"));
        customersTableStateCol.setCellValueFactory(new PropertyValueFactory<>("Division"));
        customersTableCountryCol.setCellValueFactory(new PropertyValueFactory<>("Country"));

        appointmentsTableIDCol.setCellValueFactory(new PropertyValueFactory<>("Appointment_ID"));
        appointmentsTableTitleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
        appointmentsTableDescriptionCol.setCellValueFactory(new PropertyValueFactory<>("Description"));
        appointmentsTableLocationCol.setCellValueFactory(new PropertyValueFactory<>("Location"));
        appointmentsTableContactCol.setCellValueFactory(new PropertyValueFactory<>("Contact"));
        appointmentsTableTypeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
        appointmentsTableStartCol.setCellValueFactory(new PropertyValueFactory<>("Start"));
        appointmentsTableEndCol.setCellValueFactory(new PropertyValueFactory<>("End"));
        appointmentsTableCusIDCol.setCellValueFactory(new PropertyValueFactory<>("Customer_ID"));
        appoinmentsTableUserIDCol.setCellValueFactory(new PropertyValueFactory<>("User_ID"));


        try{
            while (rsCustomers.next()) {

                Integer customerID = rsCustomers.getInt(1);
                String customerName = rsCustomers.getString(2);
                String customerAddress = rsCustomers.getString(3);
                String customerPostal = rsCustomers.getString(4);
                String customerPhone = rsCustomers.getString(5);
                String customerState = rsCustomers.getString(6);
                String customerCountry = rsCustomers.getString(7);
                Customer customer = new Customer(customerID, customerName, customerAddress, customerPostal, customerPhone, customerState, customerCountry);
                customers.add(customer);

            }

            mainMenuCustomersTableView.setItems(customers);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        try{
            while (rsAppointments.next()) {

                Integer appointmentID = rsAppointments.getInt(1);
                String Title = rsAppointments.getString(2);
                String Description = rsAppointments.getString(3);
                String Location = rsAppointments.getString(4);
                String Contact = rsAppointments.getString(5);
                String Type = rsAppointments.getString(6);

                String StartUTC = rsAppointments.getString(7);
                String EndUTC = rsAppointments.getString(8);

                Integer Customer_ID = rsAppointments.getInt(9);
                Integer User_ID = rsAppointments.getInt(10);

                Appointment appointment = new Appointment(appointmentID, Title, Description, Location, Contact, Type, StartUTC, EndUTC, Customer_ID, User_ID);
                appointments.add(appointment);
            }

            mainMenuAppointmentsTableView.setItems(appointments);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void onActionAddCustomer(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("addCustomer-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) mainMenuAddCustomerBtn.getScene().getWindow();
        currentStage.close();
    }

    public void onActionUpdateCustomer(ActionEvent actionEvent) throws IOException {

        Customer selectedRow = mainMenuCustomersTableView.getSelectionModel().getSelectedItem();

        FXMLLoader loader = new FXMLLoader(Main.class.getResource("updateCustomer-view.fxml"));
        Parent root = loader.load();
        updateCustomerController updateCustomerController = loader.getController();

        if (selectedRow != null){updateCustomerController.setCustomerData(selectedRow.getCustomer_ID(), selectedRow.getCustomer_Name(), selectedRow.getAddress(), selectedRow.getPostal_Code(), selectedRow.getPhone(), selectedRow.getDivision(), selectedRow.getCountry());
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) mainMenuAddCustomerBtn.getScene().getWindow();
            currentStage.close();}
        else{
            showError("mainMenu.noCustomerSelectedTitle", "mainMenu.noCustomerSelectedMessage");
        }

    }

    public void onActionDeleteCustomer(ActionEvent actionEvent) throws SQLException {
        Customer selectedRow = mainMenuCustomersTableView.getSelectionModel().getSelectedItem();
        if(selectedRow != null){

            Integer Appointment_ID = AppointmentsQuery.getCustomerAppointmentBooked(selectedRow.getCustomer_ID());
            if (Appointment_ID<0) {
                CustomersQuery.deleteCustomer(selectedRow.getCustomer_ID());
                ObservableList<Customer> customers = FXCollections.observableArrayList();
                ResultSet rsCustomers = CustomersQuery.accessDBCustomersTable();

                try {
                    while (rsCustomers.next()) {

                        Integer customerID = rsCustomers.getInt(1);
                        String customerName = rsCustomers.getString(2);
                        String customerAddress = rsCustomers.getString(3);
                        String customerPostal = rsCustomers.getString(4);
                        String customerPhone = rsCustomers.getString(5);
                        String customerState = rsCustomers.getString(6);
                        String customerCountry = rsCustomers.getString(7);
                        Customer customer = new Customer(customerID, customerName, customerAddress, customerPostal, customerPhone, customerState, customerCountry);
                        customers.add(customer);

                    }

                    mainMenuCustomersTableView.setItems(customers);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            else{
                showError("mainMenu.noCustomerSelectedTitle", "mainMenu.noCustomerSelectedMessage");
            }
        }
        else {
            showError("mainMenu.noCustomerSelectedTitle", "mainMenu.noCustomerSelectedMessage");
        }
    }

    public void onActionAddAppointment(ActionEvent actionEvent) throws IOException {


        FXMLLoader loader = new FXMLLoader(Main.class.getResource("addAppointment-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) mainMenuAddCustomerBtn.getScene().getWindow();
        currentStage.close();
    }

    public void onActionUpdateAppointment(ActionEvent actionEvent) throws IOException {

        Appointment selectedRow = mainMenuAppointmentsTableView.getSelectionModel().getSelectedItem();

        String startParse = selectedRow.getStart();
        String endParse = selectedRow.getEnd();
        String startDate = startParse.substring(0,(startParse.length()/2)+1);
        String startTime = startParse.substring(((startParse.length()/2)+1), startParse.length());
        String endDate = endParse.substring(0, (startParse.length()/2)+1);
        String endTime = endParse.substring(((startParse.length()/2)+1), startParse.length());

        FXMLLoader loader = new FXMLLoader(Main.class.getResource("updateAppointment-view.fxml"));
        Parent root = loader.load();
        UpdateAppointmentController updateAppointmentController = loader.getController();
        if (selectedRow != null){updateAppointmentController.setAppointmentData(selectedRow.getAppointment_ID(), selectedRow.getTitle(), selectedRow.getDescription(), selectedRow.getLocation(), selectedRow.getContact(), selectedRow.getType(), startDate, startTime, endDate, endTime, selectedRow.getCustomer_ID(), selectedRow.getUser_ID());
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) mainMenuAddCustomerBtn.getScene().getWindow();
            currentStage.close();}
        else{
            showError("mainMenu.noCustomerSelectedTitle", "mainMenu.noCustomerSelectedMessage");
        }
    }

    public void onActionDeleteAppointment(ActionEvent actionEvent) throws SQLException {
        Appointment selectedRow = mainMenuAppointmentsTableView.getSelectionModel().getSelectedItem();
        if(selectedRow != null){

            showMessage(selectedRow.getType() + " " + selectedRow.getAppointment_ID().toString(), selectedRow.getType() + " type appointment, with ID: " + selectedRow.getAppointment_ID().toString() + " was cancelled.");
            AppointmentsQuery.deleteAppointment(selectedRow.getAppointment_ID());
            ObservableList<Appointment> appointments = FXCollections.observableArrayList();
            ResultSet rsAppointments = AppointmentsQuery.accessDBAppointmentsTable();

            try{
                while (rsAppointments.next()) {

                    Integer appointmentID = rsAppointments.getInt(1);
                    String Title = rsAppointments.getString(2);
                    String Description = rsAppointments.getString(3);
                    String Location = rsAppointments.getString(4);
                    String Contact = rsAppointments.getString(5);
                    String Type = rsAppointments.getString(6);
                    String StartUTC = rsAppointments.getString(7);
                    String EndUTC = rsAppointments.getString(8);
                    Integer Customer_ID = rsAppointments.getInt(9);
                    Integer User_ID = rsAppointments.getInt(10);

                    Appointment appointment = new Appointment(appointmentID, Title, Description, Location, Contact, Type, StartUTC, EndUTC, Customer_ID, User_ID);
                    appointments.add(appointment);
                }

                mainMenuAppointmentsTableView.setItems(appointments);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            showError("mainMenu.noCustomerSelectedTitle", "mainMenu.noCustomerSelectedMessage");
        }
    }

    private void showError(String title, String message){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showMessage(String title, String message){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void onActionMonthViewTrigger(Event event) {
        LocalDate selectedDate = mainMenuScheduleDatePicker.getValue();
        LocalDate monthStart = selectedDate.withDayOfMonth(1);
        LocalDate monthEnd = selectedDate.withDayOfMonth(selectedDate.lengthOfMonth());
        ResultSet rs = AppointmentsQuery.accessDBAppointmentsMonthTable(monthStart, monthEnd);
        ObservableList<Appointment> monthAppointments = FXCollections.observableArrayList();
        try{
            while (rs.next()) {

                Integer appointmentID = rs.getInt(1);
                String Title = rs.getString(2);
                String Description = rs.getString(3);
                String Location = rs.getString(4);
                String Contact = rs.getString(5);
                String Type = rs.getString(6);
                String StartUTC = rs.getString(7);
                String EndUTC = rs.getString(8);
                Integer Customer_ID = rs.getInt(9);
                Integer User_ID = rs.getInt(10);

                Appointment appointment = new Appointment(appointmentID, Title, Description, Location, Contact, Type, StartUTC, EndUTC, Customer_ID, User_ID);
                monthAppointments.add(appointment);
            }

            mainMenuAppointmentsWeekTableView.setItems(monthAppointments);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void onActionWeekViewTrigger(Event event) {
        LocalDate selectedDate = mainMenuScheduleDatePicker.getValue();
        LocalDate weekStart = selectedDate.with(DayOfWeek.SUNDAY);
        LocalDate weekEnd = selectedDate.with(DayOfWeek.SATURDAY);
        ResultSet rs = AppointmentsQuery.accessDBAppointmentsWeekTable(weekStart, weekEnd);
        ObservableList<Appointment> weekAppointments = FXCollections.observableArrayList();
        try{
            while (rs.next()) {

                Integer appointmentID = rs.getInt(1);
                String Title = rs.getString(2);
                String Description = rs.getString(3);
                String Location = rs.getString(4);
                String Contact = rs.getString(5);
                String Type = rs.getString(6);
                String StartUTC = rs.getString(7);
                String EndUTC = rs.getString(8);
                Integer Customer_ID = rs.getInt(9);
                Integer User_ID = rs.getInt(10);

                Appointment appointment = new Appointment(appointmentID, Title, Description, Location, Contact, Type, StartUTC, EndUTC, Customer_ID, User_ID);
                weekAppointments.add(appointment);
            }

            mainMenuAppointmentsWeekTableView.setItems(weekAppointments);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void onActionSelectDate(ActionEvent actionEvent) {

    }
}
