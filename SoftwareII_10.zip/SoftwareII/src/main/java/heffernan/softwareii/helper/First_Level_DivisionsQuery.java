package heffernan.softwareii.helper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class First_Level_DivisionsQuery {

    public static ResultSet accessDBFLDTable(String country) {
        Connection connection;
        connection = JDBC.connection;
        ResultSet rs = null;

        try{

            String sql = "SELECT first_level_divisions.Division, countries.Country FROM first_level_divisions INNER JOIN countries ON first_level_divisions.Country_ID = countries.Country_ID WHERE countries.Country = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, country);
            rs = ps.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

    public static ResultSet accessDBFLDTableDivID(String division) {
        Connection connection;
        connection = JDBC.connection;
        ResultSet rs = null;

        try{

            String sql = "SELECT first_level_divisions.Division_ID FROM first_level_divisions WHERE first_level_divisions.Division = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, division);
            rs = ps.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

}
