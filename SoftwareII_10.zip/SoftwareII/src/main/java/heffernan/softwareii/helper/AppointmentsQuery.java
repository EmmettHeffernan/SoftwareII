package heffernan.softwareii.helper;

import java.sql.*;
import java.time.LocalDate;

public abstract class AppointmentsQuery {

    public static ResultSet accessDBAppointmentsTable() {
        Connection connection;
        connection = JDBC.connection;
        ResultSet rs = null;

        try{

            String sql = "SELECT appointments.Appointment_ID, appointments.Title, appointments.Description, appointments.Location, contacts.Contact_Name, appointments.Type, appointments.Start, appointments.End, appointments.Customer_ID, appointments.User_ID FROM (appointments INNER JOIN contacts ON appointments.Contact_ID = contacts.Contact_ID)";
            PreparedStatement ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

    public static ResultSet accessDBAppointmentsMonthTable(LocalDate monthStart, LocalDate monthEnd) {
        Connection connection;
        connection = JDBC.connection;
        ResultSet rs = null;

        try{

            String sql = "SELECT appointments.Appointment_ID, appointments.Title, appointments.Description, appointments.Location, contacts.Contact_Name, appointments.Type, appointments.Start, appointments.End, appointments.Customer_ID, appointments.User_ID FROM (appointments INNER JOIN contacts ON appointments.Contact_ID = contacts.Contact_ID) WHERE start >= ? AND end <= ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setObject(1, monthStart);
            ps.setObject(2, monthEnd);
            rs = ps.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

    public static ResultSet accessDBAppointmentsWeekTable(LocalDate weekStart, LocalDate weekEnd) {
        Connection connection;
        connection = JDBC.connection;
        ResultSet rs = null;

        try{

            String sql = "SELECT appointments.Appointment_ID, appointments.Title, appointments.Description, appointments.Location, contacts.Contact_Name, appointments.Type, appointments.Start, appointments.End, appointments.Customer_ID, appointments.User_ID FROM (appointments INNER JOIN contacts ON appointments.Contact_ID = contacts.Contact_ID) WHERE start >= ? AND end <= ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setObject(1, weekStart);
            ps.setObject(2, weekEnd);
            rs = ps.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

    public static int addAppointment(String Title, String Description, String Location, String Contact, String Type, String Start, String End, Integer Customer_ID, Integer User_ID) throws SQLException {
        Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
        ResultSet rs = ContactsQuery.selectContact_ID(Contact);
        Integer Contact_ID = null;
        while(rs.next()){
            Contact_ID = rs.getInt(1);
        }
        String sql = "INSERT INTO APPOINTMENTS (Appointment_ID, Title, Description, Location, Type, Start, End, Create_Date, Created_By, Last_Update, Last_Updated_By, Customer_ID, User_ID, Contact_ID) " +
                "Values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);

        ps.setInt(1, getNextAppointmentID());
        ps.setString(2,Title);
        ps.setString(3, Description);
        ps.setString(4, Location);
        ps.setString(5, Type);
        ps.setString(6, Start);
        ps.setString(7, End);
        ps.setString(8, String.valueOf(currentTimestamp));
        ps.setString(9, "script");
        ps.setString(10, String.valueOf(currentTimestamp));
        ps.setString(11, "script");
        ps.setInt(12, Customer_ID);
        ps.setInt(13, User_ID);
        ps.setInt(14, Contact_ID);

        return ps.executeUpdate();

    }


    public static int updateAppointment(int Appointment_ID, String Title, String Description, String Location, String Contact, String Type, String Start, String End, int Customer_ID, int User_ID) throws SQLException {
        Connection connection;
        connection = JDBC.connection;
        ResultSet rs = null;
        Integer Contact_ID = null;
        rs = ContactsQuery.selectContact_ID(Contact);
        while(rs.next()){
            Contact_ID = rs.getInt(1);
        }
        String sql = "UPDATE appointments SET Title = ?, Description = ?, Location = ?, Type = ?, Start = ?, End = ?, Customer_ID = ?, User_ID = ?, Contact_ID = ? WHERE Appointment_ID = ?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, Title);
        ps.setString(2, Description);
        ps.setString(3, Location);
        ps.setString(4, Type);
        ps.setString(5, Start);
        ps.setString(6, End);
        ps.setInt(7, Customer_ID);
        ps.setInt(8, User_ID);
        ps.setInt(9, Contact_ID);
        ps.setInt(10, Appointment_ID);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    public static void deleteAppointment(int Appointment_ID) throws SQLException {
        Connection connection;
        connection = JDBC.connection;
        String sql = "DELETE FROM appointments WHERE Appointment_ID = ?";
        PreparedStatement ps = connection.prepareStatement(sql);
        try(ps){
            ps.setInt(1, Appointment_ID);
            ps.executeUpdate();
        }
    }

    public static int getNextAppointmentID() throws SQLException {
        Connection connection;
        connection = JDBC.connection;
        String sql = "SELECT MAX(Appointment_ID) FROM appointments";
        PreparedStatement ps = connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            int maxID = rs.getInt(1);
            return maxID + 1;
        } else {
            return 1;
        }
    }

    public static int getCustomerAppointmentBooked(int Customer_ID) throws SQLException {
        Connection connection;
        connection = JDBC.connection;
        String sql = "SELECT Appointment_ID FROM appointments WHERE Customer_ID = ?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setInt(1, Customer_ID);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return rs.getInt(1);
        } else {
            return -1;
        }
    }

}
