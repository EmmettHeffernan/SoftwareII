package heffernan.softwareii;
import heffernan.softwareii.helper.UsersQuery;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZoneId;
import java.util.Locale;
import java.util.ResourceBundle;

public class LoginController implements Initializable {

    Stage stage;
    Parent scene;

    private ResourceBundle bundle;

    private ZoneId zoneId;

    @FXML
    private TextField loginUsernameTxtField;

    @FXML
    private PasswordField loginPasswordTxtField;

    @FXML
    private TextField loginZoneIDTxtField;

    @FXML
    private Button loginLoginBtn;

    @FXML
    private Label loginUsernameLabel;

    @FXML
    private Label loginPasswordLabel;

    @FXML
    private Label loginZoneIDLabel;

    private ZoneId userZoneId;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Locale locale = Locale.getDefault();
        bundle = ResourceBundle.getBundle("lang", locale);
        userZoneId = ZoneId.systemDefault();
        loginZoneIDTxtField.setText(userZoneId.getId());
        loginUsernameLabel.setText(bundle.getString("login.usernameLabel"));
        loginPasswordLabel.setText(bundle.getString("login.passwordLabel"));
        loginZoneIDLabel.setText(bundle.getString("login.zoneIDLabel"));
        loginLoginBtn.setText(bundle.getString("login.loginBtnLabel"));

    }

    @FXML
    void onActionLogin(ActionEvent Event) throws IOException, SQLException {

        String username = loginUsernameTxtField.getText();
        String password = loginPasswordTxtField.getText();
        ResultSet rsUsers = UsersQuery.accessDBUsersTable();

        boolean valid = credentialValidation(rsUsers, password, username);

        if(valid) {
            FXMLLoader loader = new FXMLLoader(Main.class.getResource("mainMenu-view.fxml"));
            Parent root = loader.load();
            mainMenuController menuController = loader.getController();
            userZoneId = ZoneId.systemDefault();
            menuController.setUserZoneID(userZoneId);

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage = (Stage) loginLoginBtn.getScene().getWindow();
            currentStage.close();
        }
        else {
            showError(bundle.getString("login.invalidCredentialsTitle"), bundle.getString("login.invalidCredentialsMessage"));
        }

    }

    private boolean credentialValidation(ResultSet rs, String username, String password) throws SQLException {
        while(rs.next()){
            String rsUsername = rs.getString(1);
            String rsPassword = rs.getString(2);

            if(rsUsername.equals(username) && rsPassword.equals(password)){return true;}
        }
        rs.close();
        return false;
        }

    private void showError(String title, String message){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}