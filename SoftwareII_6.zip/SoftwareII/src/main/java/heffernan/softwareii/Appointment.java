package heffernan.softwareii;

import java.security.Timestamp;
import java.time.ZonedDateTime;

public class Appointment {

    private Integer Appointment_ID;
    private String Title;
    private String Description;
    private String Location;
    private String Type;
    private ZonedDateTime Start;
    private ZonedDateTime End;
    private ZonedDateTime Created_Date;
    private Timestamp Last_Update;
    private String Last_Updated_By;

    public Appointment(Integer Appointment_ID, String Title, String Description, String Location, String Type, ZonedDateTime Start, ZonedDateTime End, ZonedDateTime Created_Date, Timestamp Last_Update, String Last_Updated_By, Integer Customer_ID, Integer User_ID, Integer Contact_ID)
    {
        this.Appointment_ID = Appointment_ID;
        this.Title = Title;
        this.Description = Description;
        this.Location = Location;
        this.Type = Type;
        this.Start = Start;
        this.End = End;
        this.Created_Date = Created_Date;
        this.Last_Update = Last_Update;
        this.Last_Updated_By = Last_Updated_By;
    }

}
