package heffernan.softwareii;

import java.security.Timestamp;
import java.time.ZonedDateTime;

public class User {

    private Integer User_ID;
    private String User_Name;
    private String Password;
    private ZonedDateTime Create_Date;
    private String Created_By;
    private Timestamp Last_Update;
    private String Last_Updated_By;

    public User(Integer User_ID, String User_Name, String Password, ZonedDateTime Create_Date, String Created_By, Timestamp Last_Update, String Last_Updated_By)
    {
        this.User_ID = User_ID;
        this.User_Name = User_Name;
        this.Password = Password;
        this.Create_Date = Create_Date;
        this.Created_By = Created_By;
        this.Last_Update = Last_Update;
        this.Last_Updated_By = Last_Updated_By;
    }

}
