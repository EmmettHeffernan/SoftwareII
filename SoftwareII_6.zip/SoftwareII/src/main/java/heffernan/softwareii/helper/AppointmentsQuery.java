package heffernan.softwareii.helper;

import java.sql.*;

public class AppointmentsQuery {

    public static ResultSet accessDBAppointmentsTable() {
        Connection connection;
        connection = JDBC.connection;
        ResultSet rs = null;

        try{

            String sql = "SELECT appointments.Appointment_ID, appointments.Title, appointments.Description, appointments.Location, contacts.Contact_Name, appointments.Type, appointments.Start, appointments.End, appointments.Customer_ID, appointments.User_ID FROM (appointments INNER JOIN contacts ON appointments.Contact_ID = contacts.Contact_ID)";
            PreparedStatement ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

}
