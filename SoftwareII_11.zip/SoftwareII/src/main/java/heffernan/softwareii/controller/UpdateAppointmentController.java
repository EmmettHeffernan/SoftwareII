package heffernan.softwareii.controller;

import heffernan.softwareii.Main;
import heffernan.softwareii.helper.AppointmentsQuery;
import heffernan.softwareii.helper.ContactsQuery;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class UpdateAppointmentController {

    @FXML
    private TextField updateAppointmentLocationTxt;

    @FXML
    private DatePicker updateAppointmentStartDate;

    @FXML
    private DatePicker updateAppointmentEndDate;

    @FXML
    private ComboBox updateAppointmentStartTime;

    @FXML
    private ComboBox updateAppointmentEndTime;

    @FXML
    private TextField updateAppointmentIDTxt;

    @FXML
    private TextField updateAppointmentTitleTxt;

    @FXML
    private TextField updateAppointmentDescriptionTxt;

    @FXML
    private ComboBox<String> updateAppointmentContactCombo;

    @FXML
    private TextField updateAppointmentTypeTxt;

    @FXML
    private TextField updateAppointmentCustomerIDTxt;

    @FXML
    private TextField updateAppointmentUserIDTxt;

    @FXML
    private Button updateAppointmentSaveBtn;

    @FXML
    private Button updateAppointmentCancelBtn;

    @FXML
    void initialize(){
        setUpdateAppointmentContactCombo();
        setUpdateAppointmentTimes();
    }

    @FXML
    void onActionSave(ActionEvent actionEvent) throws IOException, SQLException {
        Integer appointmentID = Integer.parseInt(updateAppointmentIDTxt.getText());
        String title = updateAppointmentTitleTxt.getText();
        String description = updateAppointmentDescriptionTxt.getText();
        String location = updateAppointmentLocationTxt.getText();
        String contact = updateAppointmentContactCombo.getValue();
        String type = updateAppointmentTypeTxt.getText();
        String startDate = updateAppointmentStartDate.getValue().toString();
        String startTime = (String) updateAppointmentStartTime.getValue();
        String endDate = updateAppointmentEndDate.getValue().toString();
        String endTime = (String) updateAppointmentEndTime.getValue();
        Integer customerID = Integer.parseInt(updateAppointmentCustomerIDTxt.getText());
        Integer userID = Integer.parseInt(updateAppointmentUserIDTxt.getText());
        AppointmentsQuery.updateAppointment(appointmentID, title, description, location, contact, type, startDate+" "+startTime, endDate+" "+endTime, customerID, userID);

        FXMLLoader loader = new FXMLLoader(Main.class.getResource("mainMenu-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) updateAppointmentCancelBtn.getScene().getWindow();
        currentStage.close();
    }

    @FXML
    void onActionCancel(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("mainMenu-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) updateAppointmentCancelBtn.getScene().getWindow();
        currentStage.close();
    }

    private void setUpdateAppointmentContactCombo() {
        ResultSet contacts = ContactsQuery.selectContacts();
        try {
            while (contacts.next()) {
                String contactName = contacts.getString(1);
                updateAppointmentContactCombo.getItems().add(contactName);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void setUpdateAppointmentTimes(){
        updateAppointmentStartTime.getItems().addAll("08:00:00", "09:00:00", "10:00:00", "11:00:00", "12:00:00", "13:00:00", "14:00:00", "15:00:00", "16:00:00", "17:00:00", "18:00:00", "19:00:00","20:00:00", "21:00:00");
        updateAppointmentEndTime.getItems().addAll("09:00:00", "10:00:00", "11:00:00", "12:00:00", "13:00:00", "14:00:00", "15:00:00", "16:00:00", "17:00:00", "18:00:00", "19:00:00","20:00:00", "21:00:00", "22:00:00");
    }

    public void setAppointmentData(Integer ID, String Title, String Description, String Location, String Contact, String Type, String StartDate, String StartTime, String EndDate, String EndTime, Integer Customer_ID, Integer User_ID){
        updateAppointmentIDTxt.setText(ID.toString());
        updateAppointmentTitleTxt.setText(Title);
        updateAppointmentDescriptionTxt.setText(Description);
        updateAppointmentLocationTxt.setText(Location);
        updateAppointmentContactCombo.setValue(Contact);
        updateAppointmentTypeTxt.setText(Type);
        updateAppointmentStartDate.setValue(LocalDate.parse(StartDate));
        updateAppointmentStartTime.setValue(StartTime);
        updateAppointmentEndDate.setValue(LocalDate.parse(EndDate));
        updateAppointmentEndTime.setValue(EndTime);
        updateAppointmentCustomerIDTxt.setText(Customer_ID.toString());
        updateAppointmentUserIDTxt.setText(User_ID.toString());
    }

}
