package heffernan.softwareii.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Customer {

    private final Integer Customer_ID;
    private final String Customer_Name;
    private final String Address;
    private final String Postal_Code;
    private final String Phone;
    private final String Division;
    private final String Country;


    public Customer(Integer Customer_ID, String Customer_Name, String Address, String Postal_Code, String Phone, String Division, String Country)
    {

        this.Customer_ID = Customer_ID;
        this.Customer_Name = Customer_Name;
        this.Address = Address;
        this.Postal_Code = Postal_Code;
        this.Phone = Phone;
        this.Division = Division;
        this.Country = Country;

    }

    public Integer getCustomer_ID() {
        return Customer_ID;
    }

    public String getCustomer_Name() {
        return Customer_Name;
    }

    public String getAddress() {
        return Address;
    }

    public String getPostal_Code() {
        return Postal_Code;
    }

    public String getPhone() {
        return Phone;
    }

    public String getDivision() {
        return Division;
    }

    public String getCountry(){
        return Country;
    }
}
