package heffernan.softwareii;
import heffernan.softwareii.helper.CustomersQuery;

import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Locale;
import java.util.ResourceBundle;

public class mainMenuController implements Initializable {

    @FXML
    private TableColumn<CustomersTableRow, Integer> customersTableIDCol;

    @FXML
    private TableColumn<CustomersTableRow, String> customersTableNameCol;

    @FXML
    private TableColumn<CustomersTableRow, String> customersTableAddressCol;

    @FXML
    private TableColumn<CustomersTableRow, String> customersTablePostalCodeCol;

    @FXML
    private TableColumn<CustomersTableRow, String> customersTablePhoneCol;

    @FXML
    private TableColumn<CustomersTableRow, Integer> customersTableDivisionIDCol;

    @FXML
    private TableColumn<CustomersTableRow, String> customersTableStateCol;

    @FXML
    private TableColumn<CustomersTableRow, String> customersTableCountryCol;

    @FXML
    private TableView<CustomersTableRow> mainMenuCustomersTableView;

    @FXML
    private TableView mainMenuAppointmentsTableView;

    @FXML
    private Button mainMenuAddCustomerBtn;

    @FXML
    private Button mainMenuUpdateCustomerBtn;

    @FXML
    private Button mainMenuCustomerDelete;

    @FXML
    private Button mainMenuAppointmentAddBtn;

    @FXML
    private Button mainMenuUpdateAppointmentBtn;

    @FXML
    private Button mainMenuDeleteAppointmentBtn;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        ObservableList<CustomersTableRow> customerList = FXCollections.observableArrayList();
        ResultSet rs = CustomersQuery.accessDBCustomersTable();

//        customersTableIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));
//        customersTableNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
//        customersTableAddressCol.setCellValueFactory(new PropertyValueFactory<>("address"));
//        customersTablePostalCodeCol.setCellValueFactory(new PropertyValueFactory<>("postal"));
//        customersTablePhoneCol.setCellValueFactory(new PropertyValueFactory<>("phone"));
//        customersTableDivisionIDCol.setCellValueFactory(new PropertyValueFactory<>("division"));
//        customersTableStateCol.setCellValueFactory(new PropertyValueFactory<>("state"));
//        customersTableCountryCol.setCellValueFactory(new PropertyValueFactory<>("country"));

        customersTableIDCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getCustomer_ID();
        });
        customersTableNameCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getCustomer_name();
        });
        customersTableAddressCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getAddress();
        });
        customersTablePostalCodeCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getPostal_code();
        });
        customersTablePhoneCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getPhone();
        });
        customersTableDivisionIDCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getDivision_ID();
        });
        customersTableStateCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getState();
        });
        customersTableCountryCol.setCellValueFactory(cellData -> {
            return cellData.getValue().getCountry();
        });

        try{
            rs.beforeFirst();
            while (rs.next()) {
                Integer customerID = rs.getInt("Customer_ID");
                String customerName = rs.getString("Customer_Name");
                String customerAddress = rs.getString("Address");
                String customerPostal = rs.getString("Postal_Code");
                String customerPhone = rs.getString("Phone");
                Integer customerDivision = rs.getInt("Division_ID");
                String customerState = rs.getString("Division");
                String customerCountry = rs.getString("Country");

                CustomersTableRow tr = new CustomersTableRow(
                        new ReadOnlyIntegerWrapper(customerID),
                        new ReadOnlyStringWrapper(customerName),
                        new ReadOnlyStringWrapper(customerAddress),
                        new ReadOnlyStringWrapper(customerPostal),
                        new ReadOnlyStringWrapper(customerPhone),
                        new ReadOnlyIntegerWrapper(customerDivision),
                        new ReadOnlyStringWrapper(customerState),
                        new ReadOnlyStringWrapper(customerCountry));
                customerList.add(tr);
            }
            mainMenuCustomersTableView.setItems(customerList);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void onActionAddCustomer(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("addCustomer-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) mainMenuAddCustomerBtn.getScene().getWindow();
        currentStage.close();
    }

    public void onActionUpdateCustomer(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("updateCustomer-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) mainMenuAddCustomerBtn.getScene().getWindow();
        currentStage.close();
    }

    public void onActionDeleteCustomer(ActionEvent actionEvent) {
    }

    public void onActionAddAppointment(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("addAppointment-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) mainMenuAddCustomerBtn.getScene().getWindow();
        currentStage.close();
    }

    public void onActionUpdateAppointment(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("updateAppointment-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) mainMenuAddCustomerBtn.getScene().getWindow();
        currentStage.close();
    }

    public void onActionDeleteAppointment(ActionEvent actionEvent) {
    }
}
