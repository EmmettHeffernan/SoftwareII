package heffernan.softwareii;

import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.value.ObservableValue;

public class CustomersTableRow {
    private ObservableValue<Integer> customer_ID;
    private ObservableValue<String> customer_name;
    private ObservableValue<String> address;
    private ObservableValue<String> postal_code;
    private ObservableValue<String> phone;
    private ObservableValue<Integer> division_ID;
    private ObservableValue<String> state;
    private ObservableValue<String> country;

    public CustomersTableRow(ObservableValue<Integer> customer_ID, ObservableValue<String> customer_name, ObservableValue<String> address, ObservableValue<String> postal_code, ObservableValue<String> phone, ObservableValue<Integer> division_ID, ObservableValue<String> state, ObservableValue<String> country){
        this.customer_ID = customer_ID;
        this.customer_name = customer_name;
        this.address = address;
        this.postal_code = postal_code;
        this.phone = phone;
        this.division_ID = division_ID;
        this.state = state;
        this.country = country;
    }

    public CustomersTableRow(ReadOnlyIntegerWrapper readOnlyIntegerWrapper, ReadOnlyStringWrapper customer_name, ReadOnlyStringWrapper address, ReadOnlyStringWrapper postal_code, ReadOnlyStringWrapper phone, ReadOnlyIntegerWrapper readOnlyIntegerWrapper1, ReadOnlyStringWrapper state, ReadOnlyStringWrapper country) {
    }

    public ObservableValue<Integer> getCustomer_ID() {return customer_ID;}

    public ObservableValue<String> getCustomer_name() {return customer_name;}

    public ObservableValue<String> getAddress() {return address;}

    public ObservableValue<String> getPostal_code() {return postal_code;}

    public ObservableValue<String> getPhone() {return phone;}

    public ObservableValue<Integer> getDivision_ID() {return division_ID;}

    public ObservableValue<String> getState() {return state;}

    public ObservableValue<String> getCountry() {return country;}

}
