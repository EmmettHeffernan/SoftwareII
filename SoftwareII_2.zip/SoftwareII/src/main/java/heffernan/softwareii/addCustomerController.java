package heffernan.softwareii;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class addCustomerController {


    @FXML
    private TextField addCustomerIDTxt;

    @FXML
    private TextField addCustomerNameTxt;

    @FXML
    private TextField addCustomerAddressTxt;

    @FXML
    private TextField addCustomerPostalCodeTxt;

    @FXML
    private ComboBox addCustomerCountryCombo;

    @FXML
    private ComboBox addCustomerFLDCombo;

    @FXML
    private TextField addCustomerPhoneTxt;

    @FXML
    private Button addCustomerSaveBtn;

    @FXML
    private Button addCustomerCancelBtn;

    @FXML
    void onActionSave(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("mainMenu-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) addCustomerSaveBtn.getScene().getWindow();
        currentStage.close();
    }

    @FXML
    void onActionCancel(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("mainMenu-view.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();

        Stage currentStage = (Stage) addCustomerCancelBtn.getScene().getWindow();
        currentStage.close();
    }
}
