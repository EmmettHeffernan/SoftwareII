package heffernan.softwareii.helper;

import java.sql.*;
import java.time.ZonedDateTime;

public class UsersQuery {

    public static ResultSet accessDBUsersTable() {
        Connection connection;
        connection = JDBC.connection;
        ResultSet rs = null;

        try{

            String sql = "SELECT users.User_Name, users.Password FROM users";
            PreparedStatement ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

    public static int getUser_ID(String userName, String password) throws SQLException {
        Connection connection;
        connection = JDBC.connection;
        String sql = "SELECT users.User_ID FROM users WHERE users.User_Name = ? AND users.Password = ?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, userName);
        ps.setString(2, password);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            int ID = rs.getInt(1);
            return ID;
        } else{
            return -1;
        }
    }

}
