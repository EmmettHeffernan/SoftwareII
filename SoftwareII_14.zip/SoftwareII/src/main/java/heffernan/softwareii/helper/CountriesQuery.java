package heffernan.softwareii.helper;

import java.sql.*;

public class CountriesQuery {

    public static ResultSet accessDBCountriesTable() {
        Connection connection;
        connection = JDBC.connection;
        ResultSet rs = null;

        try{

            String sql = "SELECT * FROM countries";
            PreparedStatement ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

    public static ResultSet getCustomerCountByCountry(){
        Connection connection;
        connection = JDBC.connection;
        ResultSet rs = null;

        try{

            String sql = "SELECT countries.Country, COUNT(customers.Customer_ID) AS CustomerCount " +
                    "FROM countries LEFT JOIN first_level_divisions ON countries.Country_ID = first_level_divisions.Country_ID " +
                    "LEFT JOIN customers ON first_level_divisions.Division_ID = customers.Division_ID " +
                    "GROUP BY countries.Country " +
                    "ORDER BY countries.Country";
            PreparedStatement ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

}
