package heffernan.softwareii.helper;

import java.sql.*;

public class ContactsQuery {

    public static ResultSet selectContacts() {
        Connection connection;
        connection = JDBC.connection;
        ResultSet rs = null;
        try{

            String sql = "SELECT Contact_Name FROM contacts";
            PreparedStatement ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

    public static ResultSet selectContact_ID(String Contact_Name) {
        Connection connection;
        connection = JDBC.connection;
        ResultSet rs = null;
        try{
            String sql = "SELECT Contact_ID FROM contacts WHERE contacts.Contact_Name = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, Contact_Name);
            rs = ps.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

}
