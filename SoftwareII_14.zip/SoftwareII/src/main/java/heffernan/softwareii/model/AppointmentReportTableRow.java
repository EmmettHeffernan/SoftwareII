package heffernan.softwareii.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class AppointmentReportTableRow {
    private final StringProperty appointmentType;
    private final StringProperty month;
    private final IntegerProperty totalAppointments;

    public AppointmentReportTableRow(String appointmentType, String month, Integer totalAppointments) {
        this.appointmentType = new SimpleStringProperty(appointmentType);
        this.month = new SimpleStringProperty(month);
        this.totalAppointments = new SimpleIntegerProperty(totalAppointments);
    }

    public StringProperty getAppointmentType() {
        return appointmentType;
    }

    public StringProperty getMonth() {
        return month;
    }

    public IntegerProperty getTotalAppointments() {
        return totalAppointments;
    }

}
