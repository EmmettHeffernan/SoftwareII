package heffernan.softwareii.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

import javax.xml.stream.Location;
import java.security.Timestamp;
import java.time.ZonedDateTime;

public class Appointment {

    private final Integer Appointment_ID;
    private final String Title;
    private final String Description;
    private final String Location;
    private final String Contact;
    private final String Type;
    private final String Start;
    private final String End;
    private final Integer Customer_ID;
    private final Integer User_ID;

    public Appointment(Integer Appointment_ID, String Title, String Description, String Location, String Contact, String Type, String Start, String End, Integer Customer_ID, Integer User_ID)
    {
        this.Appointment_ID = Appointment_ID;
        this.Title = Title;
        this.Description = Description;
        this.Location = Location;
        this.Contact = Contact;
        this.Type = Type;
        this.Start = Start;
        this.End = End;
        this.Customer_ID = Customer_ID;
        this.User_ID = User_ID;
    }

    public Integer getAppointment_ID() {
        return Appointment_ID;
    }

    public String getTitle() {
        return Title;
    }

    public String getDescription() {
        return Description;
    }

    public String getLocation() {
        return Location;
    }

    public String getType() {
        return Type;
    }

    public String getContact() {
        return Contact;
    }

    public String getStart() {
        return Start;
    }

    public String getEnd() {
        return End;
    }

    public Integer getCustomer_ID() {
        return Customer_ID;
    }

    public Integer getUser_ID() {
        return User_ID;
    }

}
