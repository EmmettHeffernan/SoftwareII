package heffernan.softwareii.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class CustomersReportTableRow {
    private final StringProperty country;
    private final IntegerProperty customerCount;

    public CustomersReportTableRow(String country, Integer customerCount) {
        this.country = new SimpleStringProperty(country);
        this.customerCount = new SimpleIntegerProperty(customerCount);
    }

    public StringProperty getCountry(){
        return country;
    }

    public IntegerProperty getCustomerCount(){
        return customerCount;
    }

}
