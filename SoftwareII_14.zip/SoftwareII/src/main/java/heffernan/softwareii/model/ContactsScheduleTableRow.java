package heffernan.softwareii.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class ContactsScheduleTableRow {
    private final IntegerProperty appointmentID;
    private final StringProperty title;
    private final StringProperty type;
    private final StringProperty description;
    private final StringProperty start;
    private final StringProperty end;
    private final IntegerProperty customerID;

    public ContactsScheduleTableRow(Integer appointmentID, String title, String type, String description, String start, String end, Integer customerID) {
        this.appointmentID = new SimpleIntegerProperty(appointmentID);
        this.title = new SimpleStringProperty(title);
        this.type = new SimpleStringProperty(type);
        this.description = new SimpleStringProperty(description);
        this.start = new SimpleStringProperty(start);
        this.end = new SimpleStringProperty(end);
        this.customerID = new SimpleIntegerProperty(customerID);
    }

    public IntegerProperty getAppointmentID(){
        return appointmentID;
    }

    public StringProperty getTitle() {
        return title;
    }

    public StringProperty getType() {
        return type;
    }

    public StringProperty getDescription() {
        return description;
    }

    public StringProperty getStart() {
        return start;
    }

    public StringProperty getEnd() {
        return end;
    }

    public IntegerProperty getCustomerID() {
        return customerID;
    }

}
